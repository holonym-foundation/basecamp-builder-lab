@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 24 from https://nodejs.org/en/download and try again.
  pause
  exit /b 1
)
node server.mjs --open
pause
