const $ = id => document.getElementById(id);
const steps = [
  {id:'prepare',label:'Prepare runtime',title:'Prepare the runtime.',description:'Check Node and the recipe source before installation.'},
  {id:'configure',label:'Wallet + configure',title:'Set up the wallet and strategy.',description:'Create and approve the wallet, save its address, then fund it before the first funded run.'},
  {id:'deploy',label:'Deploy',title:'Deploy the agent.',description:'Install the standalone recipe and its dependencies in the isolated runtime.'},
  {id:'run',label:'Start / run',title:'Read. Decide. Build.',description:'Run one cycle against mainnet data, or start repeated monitoring. Transaction signing is disabled.'},
  {id:'inspect',label:'Inspect',title:'Inspect the result.',description:'Compare the price, wallet balances and proposed action with the actual execution output.'},
  {id:'modify',label:'Modify',title:'Change the strategy.',description:'Update a threshold or desired position value, then run again and inspect the difference.'},
  {id:'stop',label:'Stop',title:'Stop the runtime.',description:'End monitoring and retain the last output and execution log.'},
];
const stageLabels = {idle:'Ready to prepare',prepared:'Runtime prepared',configured:'Configuration saved',deployed:'Dependencies installed',running:'Agent running',stopped:'Agent stopped',error:'Operation failed'};
let state = null, token = null, connected = false, pending = null, selected = 0;
let stoppingPending = false;
let refreshing = false, panelKey = '', draft = null, draftDirty = false, localError = '', eventKey = '', outputKey = '';
const safeMode = () => state?.config?.network === 'mainnet' && state?.config?.dryRun === true;
const prepared = () => state?.runtime?.prepared === true || ['prepared','configured','deployed','running','stopped'].includes(state?.stage);
const configured = () => state?.configured === true;
const installed = () => state?.runtime?.installed === true;
const hasRun = () => state?.lastRun !== null && state?.lastRun !== undefined;
const available = () => connected && token && !pending && !stoppingPending && !state?.busy && safeMode();
const canStop = () => connected && token && !stoppingPending && Boolean(state?.running || state?.busy || pending);
const sourceValue = () => typeof state?.runtime?.source === 'object' ? state.runtime.source?.source ?? state.runtime.source?.url ?? 'Source metadata available' : state?.runtime?.source;
const runnable = () => available() && configured() && installed() && !state?.running;
const text = (node,value) => { node.textContent = value === null || value === undefined ? 'Not reported' : String(value); };
const element = (tag,cls,value) => {const node=document.createElement(tag);if(cls)node.className=cls;if(value!==undefined)text(node,value);return node;};
const short = value => typeof value==='string'&&value.length>52 ? value.slice(0,24)+'…'+value.slice(-20) : String(value??'Not reported');

function showError(message) {localError=message || '';renderBanner();}
function renderBanner() {
  const serverError=state?.error;
  const message=localError || (typeof serverError==='string' ? serverError : serverError?.message) || '';
  $('error-banner').hidden=!message;text($('error-banner'),message);
}
function selectFromHash() {
  const index=steps.findIndex(step=>'#'+step.id===location.hash);
  selected=index<0?0:index;draft=null;draftDirty=false;render();
}
function selectStep(index) {location.hash=steps[Math.max(0,Math.min(steps.length-1,index))].id;}
function completed(index) {
  return [prepared(),configured(),installed(),hasRun(),false,false,state?.stage==='stopped'&&!state?.running][index];
}
function renderNavigation() {
  if(!$('steps').children.length) steps.forEach((step,index)=>{
    const button=element('button','step-tab');button.type='button';button.append(element('span','step-number',String(index+1).padStart(2,'0')),element('span','',step.label));button.onclick=()=>selectStep(index);$('steps').append(button);
  });
  [...$('steps').children].forEach((button,index)=>{button.classList.toggle('active',index===selected);button.classList.toggle('complete',completed(index));if(index===selected)button.setAttribute('aria-current','step');else button.removeAttribute('aria-current');});
  $('previous-step').disabled=selected===0;
  $('next-step').disabled=selected===steps.length-1;
  text($('next-step'),selected<steps.length-1?'Next: '+steps[selected+1].label.toLowerCase()+' →':'Final step');
}
function facts(rows) {
  const box=element('div','facts');for(const [label,value]of rows){const row=element('div','fact');row.append(element('span','',label),element('strong','',value));box.append(row);}return box;
}
function notice(message,warning=false) {return element('div','notice'+(warning?' warning':''),message);}
function button(label,callback,disabled=false,secondary=false) {
  const node=element('button','action'+(secondary?' secondary':''),label);node.type='button';node.disabled=Boolean(disabled);node.onclick=callback;return node;
}
function actionButton(action,label,allowed,secondary=false) {
  return button((pending===action||(action==='stop'&&stoppingPending))?label.replace(/\.$/,'')+'…':label,()=>perform(action),!allowed,secondary);
}
function configForm() {
  const form=element('form','config-form');form.id='strategy-config';form.autocomplete='off';
  const values=draft ?? state?.config ?? {};
  const fields=[['wallet','Public Sui wallet address','text','0x…'],['targetUsd','Desired SUI position value (USD)','number',''],['pollSeconds','Monitoring interval (seconds)','number',''],['lowPrice','Low price threshold (USD / SUI)','number',''],['highPrice','High price threshold (USD / SUI)','number','']];
  for(const [name,label,type,placeholder]of fields){
    const wrap=element('div','field'+(name==='wallet'?' full':'')),labelNode=element('label','',label),input=element('input');
    input.id='config-'+name;input.name=name;input.type=type;input.placeholder=placeholder;input.required=true;input.value=values[name]??'';input.disabled=Boolean(pending||state?.running||state?.busy);labelNode.htmlFor=input.id;
    if(type==='number'){input.step=name==='pollSeconds'?'1':'any';input.min=name==='pollSeconds'?'30':'0.000001';}
    else{input.spellcheck=false;input.maxLength=66;input.setAttribute('autocapitalize','none');}
    input.oninput=()=>{draftDirty=true;draft=readConfig(false);};wrap.append(labelNode,input);form.append(wrap);
  }
  const hint=element('p','field-hint field full','Desired position value is a strategy target, not a spending limit. Monitoring runs at least 30 seconds apart.');form.append(hint);
  form.onsubmit=event=>{event.preventDefault();if(available()&&prepared()&&!state?.running)perform('configure');};return form;
}
function readConfig(validate=true) {
  const form=$('strategy-config');if(!form)return null;
  if(validate&&!form.reportValidity())return null;
  const values=Object.fromEntries(['wallet','targetUsd','lowPrice','highPrice','pollSeconds'].map(name=>[name,form.elements.namedItem(name)?.value??'']));
  const config={wallet:String(values.wallet??'').trim(),targetUsd:Number(values.targetUsd),lowPrice:Number(values.lowPrice),highPrice:Number(values.highPrice),pollSeconds:Number(values.pollSeconds),network:'mainnet',dryRun:true};
  if(validate){
    if(!/^0x[0-9a-fA-F]{64}$/.test(config.wallet)||BigInt(config.wallet)<=15n){showError('Enter the full public Sui wallet address. No private key or recovery phrase.');return null;}
    if(![config.targetUsd,config.lowPrice,config.highPrice,config.pollSeconds].every(Number.isFinite)||config.targetUsd<=0||config.lowPrice<=0||config.highPrice<=config.lowPrice||config.pollSeconds<30||!Number.isInteger(config.pollSeconds)){showError('Use positive values, a high price above the low price, and a whole-number interval of at least 30 seconds.');return null;}
  }
  return config;
}
function renderPanel(force=false) {
  const key=JSON.stringify([selected,prepared(),configured(),installed(),state?.running,state?.busy,state?.stage,hasRun(),Boolean(available()),pending,stoppingPending]);
  if(!force&&key===panelKey)return;
  if(draftDirty&&$('strategy-config'))draft=readConfig(false);
  panelKey=key;const step=steps[selected],content=$('step-content'),actions=$('step-actions');content.replaceChildren();actions.replaceChildren();
  text($('step-eyebrow'),String(selected+1).padStart(2,'0')+' / '+step.label.toUpperCase());text($('step-title'),step.title);text($('step-description'),step.description);
  if(step.id==='prepare'){
    content.append(facts([['Node runtime',state?.runtime?.node??'Not checked'],['Recipe source',short(sourceValue())],['Runtime check',prepared()?'Passed':'Not completed']]));
    actions.append(actionButton('prepare',prepared()?'Check runtime again':'Prepare runtime',available()&&!state?.running));
  }else if(step.id==='configure'||step.id==='modify'){
    if(!prepared())content.append(notice('Prepare the runtime before saving configuration.',true));
    if(state?.running||state?.busy)content.append(notice('Stop the active process before changing the configuration.',true));
    if(step.id==='configure'){
      content.append(element('h3','setup-heading','1. Wallet'));
      content.append(element('p','note','Create or sign in to your wallet. Complete its email approval, then copy its Sui mainnet receive address. Account approval happens in your wallet service, outside this console.'));
      const historical=state?.runtime?.source?.historicalWallet?.address;
      if(historical&&state?.config?.wallet===historical)content.append(notice('This is a historical example address. Do not fund it. Replace it with the verified address of a wallet you control.',true));
      content.append(element('h3','setup-heading','2. Strategy'));
    }
    content.append(configForm());
    if(step.id==='configure'){
      const funding=element('details','wallet-help');funding.append(element('summary','','3. Funding · after saving the address'));
      const list=element('ol','list');for(const copy of ['Match the full saved address to your wallet’s Sui mainnet receive address before transferring anything.','Receive the agreed workshop allocation in that wallet. Save the transfer receipt and verify the balance.','Continue to Deploy, then Run once. The output checks actual balances and keeps 0.02 SUI reserved for gas.'])list.append(element('li','',copy));funding.append(list);content.append(funding);
    }
    actions.append(actionButton('configure',step.id==='modify'?'Apply configuration':'Save configuration',available()&&prepared()&&!state?.running));
    if(state?.running||state?.busy||pending)actions.append(actionButton('stop','Stop active process',canStop(),true));
    if(step.id==='modify'&&configured()&&!state?.running)actions.append(button('Open run controls',()=>selectStep(3),false,true));
  }else if(step.id==='deploy'){
    content.append(facts([['Runtime',prepared()?'Prepared':'Preparation required'],['Strategy',configured()?'Configuration saved':'Configuration required'],['Dependencies',installed()?'Installed':'Not installed']]));
    if(installed())content.append(notice('The standalone recipe is installed. Run one cycle to inspect its output.'));
    actions.append(actionButton('deploy',installed()?'Agent deployed':'Deploy agent',available()&&prepared()&&configured()&&!installed()&&!state?.running));
  }else if(step.id==='run'){
    content.append(facts([['Network',state?.config?.network??'Not reported'],['Mode',safeMode()?'Transaction dry-run':'Not verified'],['Desired position',state?.config?.targetUsd!==undefined?'$'+state.config.targetUsd:'Not configured'],['Monitoring',state?.running?'Running':state?.config?.pollSeconds?state.config.pollSeconds+' seconds between cycles':'Not configured']]));
    content.append(element('p','note','A cycle reads the pool and wallet, evaluates the strategy, and builds a route when its conditions and available balances allow. A dry-run does not submit a transaction.'));
    actions.append(actionButton('run','Run once',runnable()),actionButton('start',state?.running?'Monitoring active':'Start monitoring',runnable(),true));
  }else if(step.id==='inspect'){
    const list=element('ol','list');for(const item of ['Check the price and balances returned by mainnet.','Identify the proposed action or the reason no action was built.','Inspect the raw output and any reported transaction reference.'])list.append(element('li','',item));content.append(list);
    actions.append(button('Refresh result',()=>refresh(),refreshing||Boolean(pending)),button('Save output',downloadOutput,!hasRun(),true));
  }else if(step.id==='stop'){
    content.append(facts([['Monitoring',state?.running?'Running':'Not running'],['Last run',hasRun()?'Output retained':'No output received'],['Signing',safeMode()?'Disabled':'Mode not verified']]));
    if(state?.stage==='stopped')content.append(notice('The runtime is stopped. Its output and execution log remain available.'));
    actions.append(actionButton('stop','Stop agent',canStop()),button('Save output',downloadOutput,!hasRun(),true));
  }
}

function structuredRecords(value) {
  const records=[];let visited=0;
  function visit(item,depth=0){
    if(++visited>1000||depth>7||item===null||item===undefined)return;
    if(typeof item==='string'){
      for(const line of item.split('\n').slice(-100)){const trimmed=line.trim();if(trimmed.startsWith('{'))try{visit(JSON.parse(trimmed),depth+1);}catch{}}
    }else if(Array.isArray(item))item.slice(-100).forEach(child=>visit(child,depth+1));
    else if(typeof item==='object'){records.push(item);for(const [key,child]of Object.entries(item))if(!['txBytes','wallet','source'].includes(key)&&(typeof child==='object'||['stdout','output','logs','text'].includes(key)))visit(child,depth+1);}
  }
  visit(value);return records;
}
function number(value,max=6) {const n=Number(value);return value!==null&&value!==''&&Number.isFinite(n)?n.toLocaleString('en-US',{maximumFractionDigits:max}):String(value);}
function metric(label,value,unit='') {const node=element('div','metric'),strong=element('strong','',value);node.append(element('span','',label),strong);if(unit)strong.append(element('small','',unit));return node;}
function renderOutput() {
  const raw=hasRun()?JSON.stringify(state.lastRun,null,2):'';
  if(raw===outputKey)return;outputKey=raw;
  $('output-empty').hidden=hasRun();$('output-content').hidden=!hasRun();$('download-output').disabled=!hasRun();
  text($('raw-output'),raw?(raw.length>120000?raw.slice(0,120000)+'\n… Display shortened. Save output for the complete result.':raw):'No output received.');
  $('result-metrics').replaceChildren();$('explorer-links').replaceChildren();
  if(!hasRun()){text($('result-kind'),'Awaiting output');return;}
  const records=structuredRecords(state.lastRun);
  const find=predicate=>records.filter(predicate).at(-1);
  const price=find(row=>row.message==='price_check')||find(row=>row.price!==undefined&&row.targetBalance!==undefined);
  const proposal=find(row=>row.message==='rebalance_triggered');
  const dry=find(row=>row.message==='dry_run_swap');
  const unsigned=find(row=>row.message==='unsigned_swap_built');
  const complete=find(row=>row.message==='run_complete');
  const funding=find(row=>row.message==='funding_required');
  const failure=find(row=>row.level==='error'||row.error)||((state.lastRun.exitCode??state.lastRun.code)>0?state.lastRun:null);
  let summary='Runtime output received. Inspect the raw result for details.',kind='Runtime output';
  if(complete?.outcome==='BLOCKED_GAS_RESERVE'){
    summary='Live price and balances were read. The wallet does not meet the SUI reserve requirement for an unsigned swap build.';kind='Gas reserve required';
  }else if(complete?.outcome?.startsWith('BLOCKED')){
    summary='Live execution reached a funding or strategy constraint. Inspect the required balances and raw output.';kind=complete.outcome.replaceAll('_',' ');
  }else if(complete?.outcome==='SIMULATED_UNSIGNED'){
    summary='An unsigned swap was built and simulated against mainnet. No transaction was submitted.';kind='Unsigned simulation';
  }else if(complete?.outcome==='HOLD'){
    summary='Live reads completed. The strategy returned HOLD; no swap was built.';kind='HOLD';
  }else if(complete?.outcome==='FAILED'){
    summary='The run reported a failure. Inspect the actual error before another action.';kind='Run failed';
  }else if(dry){summary='A '+String(dry.direction||'swap')+' route was built in transaction dry-run mode.';kind='Dry-run route';}
  else if(unsigned){summary='An unsigned swap was built. Inspect the simulation result; no submission is reported.';kind='Unsigned build';}
  else if(proposal){summary='The strategy proposed '+String(proposal.direction||'a rebalance').toUpperCase()+'. '+(failure?'The run reported an error.':'Inspect the output for the route result.');kind=failure?'Run reported error':'Proposal';}
  else if(price){summary=failure?'Mainnet data was read. The run then reported an error.':'Live price and wallet balances were read. No rebalance was reported.';kind=failure?'Run reported error':'Live read';}
  else if(failure){summary='The run reported an error. Inspect the output before another action.';kind='Run reported error';}
  text($('result-summary'),summary);text($('result-kind'),kind);
  if(price){
    if(price.price!==undefined)$('result-metrics').append(metric('Pool price',number(price.price),'USD'));
    if(price.targetBalance!==undefined)$('result-metrics').append(metric('Target token balance',number(price.targetBalance)));
    if(price.targetValueUsd!==undefined)$('result-metrics').append(metric('Position value','$'+number(price.targetValueUsd,2)));
    if(price.quoteBalance!==undefined)$('result-metrics').append(metric('Quote token balance',number(price.quoteBalance)));
  }
  if(funding?.requiredSuiReserve!==undefined)$('result-metrics').append(metric('Required SUI reserve',number(funding.requiredSuiReserve),'SUI'));
  if(dry?.quotedOutRaw!==undefined)$('result-metrics').append(metric('Quoted output · base units',dry.quotedOutRaw));
  if(dry?.txBytes!==undefined)$('result-metrics').append(metric('Encoded transaction length',dry.txBytes,'characters'));
  const digests=new Set();for(const record of records.filter(row=>row.submitted===true||row.message==='rebalance_complete'||row.status==='confirmed'))for(const key of ['txHash','transactionDigest','digest']){const value=record[key];if(typeof value==='string'&&/^[1-9A-HJ-NP-Za-km-z]{32,64}$/.test(value))digests.add(value);}
  const checkpoint=find(row=>row.message==='chain_checkpoint');
  if(checkpoint&&/^\d+$/.test(String(checkpoint.checkpoint))){const link=element('a','','Inspect checkpoint '+checkpoint.checkpoint+' ↗');link.href='https://suiscan.xyz/mainnet/checkpoint/'+checkpoint.checkpoint;link.target='_blank';link.rel='noopener noreferrer';$('explorer-links').append(link);}
  for(const digest of [...digests].slice(0,4)){const link=element('a','','Inspect reported transaction ↗');link.href='https://suiscan.xyz/mainnet/tx/'+encodeURIComponent(digest);link.target='_blank';link.rel='noopener noreferrer';$('explorer-links').append(link);}
}
function timeLabel(value) {const date=new Date(value);return Number.isFinite(date.getTime())?date.toLocaleTimeString('en-GB',{hour12:false}):String(value??'—');}
function renderEvents() {
  const events=Array.isArray(state?.events)?state.events:[],key=JSON.stringify(events);
  if(key===eventKey)return;eventKey=key;
  const list=$('event-list'),atEnd=list.scrollHeight-list.scrollTop-list.clientHeight<35;list.replaceChildren();
  if(!events.length)list.append(element('li','no-events','Events appear only when reported by the runtime.'));
  for(const event of events.slice(-100)){
    const row=element('li','event-row'),status=String(event.status??'reported'),tone=/success|complete|done|ready|stopped/i.test(status)?' success':/error|fail/i.test(status)?' error':'';
    row.append(element('time','event-time',timeLabel(event.time)),element('span','event-operation',event.operation??'runtime'),element('span','event-status'+tone,status),element('span','event-message',typeof event.message==='string'?event.message:JSON.stringify(event.message??'')));list.append(row);
  }
  text($('event-count'),events.length?events.length+' reported event'+(events.length===1?'':'s'):'No events received');
  if(atEnd)list.scrollTop=list.scrollHeight;
}
function renderSource() {
  const holder=$('source-reference'),source=sourceValue();holder.replaceChildren();if(!source)return;
  let url;try{url=new URL(String(source),location.href);}catch{}
  if(url&&(['http:','https:'].includes(url.protocol))&&(/^(https?:\/\/|\/)/.test(String(source)))){const a=element('a','','Recipe source ↗');a.href=url.href;a.target='_blank';a.rel='noopener noreferrer';holder.append(a);}
  else text(holder,'Source: '+short(source));
}
function render() {
  renderNavigation();renderPanel();renderBanner();renderOutput();renderEvents();renderSource();
  text($('stage-label'),connected?(stageLabels[state?.stage]||state?.stage||'Status received'):'Runtime disconnected');
  $('connection-dot').className='status-dot '+(connected?'connected':'offline');
  text($('mode-label'),safeMode()?'Live mainnet · transaction dry-run':connected?'Runtime mode not verified':'Connecting to runtime');
  $('running-indicator').hidden=!state?.running;
  $('stop-runtime').hidden=!(state?.running||state?.busy||pending||stoppingPending);$('stop-runtime').disabled=!canStop();text($('stop-runtime'),stoppingPending?'Stopping…':'Stop process');
  text($('cost-label'),safeMode()?'Transaction gas: 0 SUI spent · signing disabled':'Signing mode not verified.');
}
async function session() {
  const response=await fetch('/api/session',{cache:'no-store',credentials:'same-origin',signal:AbortSignal.timeout(10000)});
  if(!response.ok)throw Error('Runtime controls are unavailable. Refresh the connection.');
  const data=await response.json();if(typeof data.token!=='string'||!data.token)throw Error('Runtime controls did not return a session.');token=data.token;
}
async function refresh() {
  if(refreshing)return;refreshing=true;
  try{
    const response=await fetch('/api/status',{cache:'no-store',credentials:'same-origin',signal:AbortSignal.timeout(10000)});
    if(!response.ok)throw Error('The runtime did not return its status.');
    const next=await response.json();if(!next||typeof next.stage!=='string'||!next.runtime||!next.config)throw Error('The runtime returned an incomplete status.');
    state=next;connected=true;text($('updated-at'),'Updated '+new Date().toLocaleTimeString('en-GB',{hour12:false}));
  }catch(error){connected=false;showError(error.message||'Cannot reach the runtime. Check the local connection, then refresh.');}
  finally{refreshing=false;render();}
}
async function perform(action) {
  const stopping=action==='stop';
  if(stopping?!canStop():!available())return;
  let config;if(action==='configure'){config=readConfig();if(!config)return;}
  if(stopping)stoppingPending=true;else pending=action;showError('');render();
  try{
    const response=await fetch('/api/action',{method:'POST',cache:'no-store',credentials:'same-origin',headers:{'Content-Type':'application/json','X-Workshop-Token':token},body:JSON.stringify({action,...(config?{config}:{})}),signal:AbortSignal.timeout(180000)});
    let result;try{result=await response.json();}catch{throw Error('The operation returned no readable result. Refresh runtime status before another action.');}
    if(!response.ok){if(response.status===401||response.status===403)token=null;throw Error(typeof result.error==='string'?result.error:result.error?.message||'The runtime could not complete this operation.');}
    if(action==='configure'){draft=null;draftDirty=false;}
  }catch(error){showError(error.name==='TimeoutError'||error.name==='AbortError'?'The request was interrupted. Check the execution log and refresh runtime status before another action.':error.message||'The request was interrupted. Check runtime status.');}
  finally{if(stopping)stoppingPending=false;else if(pending===action)pending=null;await refresh();renderPanel(true);}
}
function downloadOutput() {
  if(!hasRun())return;
  const data={savedAt:new Date().toISOString(),network:state.config.network,dryRun:state.config.dryRun,config:state.config,lastRun:state.lastRun};
  const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)+'\n'],{type:'application/json'})),link=element('a');link.href=url;link.download='sui-rebalancer-output-'+new Date().toISOString().replace(/[:.]/g,'-')+'.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
$('stop-runtime').onclick=()=>perform('stop');
$('previous-step').onclick=()=>selectStep(selected-1);$('next-step').onclick=()=>selectStep(selected+1);$('download-output').onclick=downloadOutput;
$('refresh-status').onclick=async()=>{showError('');if(!token)try{await session();}catch(error){showError(error.message);}await refresh();};
window.addEventListener('hashchange',selectFromHash);
selectFromHash();
try{await session();}catch(error){showError(error.message);}
await refresh();setInterval(refresh,3000);
