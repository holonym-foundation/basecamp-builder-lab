const $ = id => document.getElementById(id);
const steps = [
  {id:'prepare',label:'Check runtime',title:'Check the runtime.',description:'The console is open. Check Node 24 and the recipe files before installing the agent.'},
  {id:'configure',label:'Wallet + configure',title:'Set up the wallet and strategy.',description:'Create and approve the wallet, save its address, then fund it before the first funded run.'},
  {id:'deploy',label:'Install agent',title:'Install the agent.',description:'This is the installation step. The button runs npm ci against the recipe’s pinned dependency list.'},
  {id:'run',label:'Start / run',title:'Read. Decide. Build.',description:'Run one cycle against mainnet data, or start repeated monitoring. Transaction signing is disabled.'},
  {id:'inspect',label:'Inspect',title:'Inspect the result.',description:'Compare the price, wallet balances and proposed action with the actual execution output.'},
  {id:'modify',label:'Modify',title:'Change the strategy.',description:'Update a threshold or desired position value, then run again and inspect the difference.'},
  {id:'stop',label:'Stop',title:'Stop the runtime.',description:'End monitoring and retain the last output and execution log.'},
];
const stageLabels = {idle:'Ready to prepare',prepared:'Runtime prepared',configured:'Configuration saved',deployed:'Dependencies installed',running:'Agent running',stopped:'Agent stopped',error:'Operation failed'};
let state = null, token = null, connected = false, pending = null, selected = 0;
let stoppingPending = false, configPart = new URLSearchParams(location.search).get('setup')==='funding'?2:0, fundingEmail = '', fundingPending = false, fundingReceipt = null;
const FUNDING_API='https://sui-basecamp-funding.j94fv2pvjn.chatgpt.site';
const fundingQuery='?intake=email'+(new URLSearchParams(location.search).get('rehearsal')==='1'?'&rehearsal=1':'');
let refreshing = false, panelKey = '', draft = null, draftDirty = false, localError = '', eventKey = '', outputKey = '';
const safeMode = () => state?.config?.network === 'mainnet' && state?.config?.dryRun === true;
const prepared = () => state?.runtime?.prepared === true || ['prepared','configured','deployed','running','stopped'].includes(state?.stage);
const configured = () => state?.configured === true;
const installed = () => state?.runtime?.installed === true;
const hasRun = () => state?.lastRun !== null && state?.lastRun !== undefined;
const available = () => connected && token && !pending && !stoppingPending && !state?.busy && safeMode();
const canStop = () => connected && token && !stoppingPending && Boolean(state?.running || state?.busy || pending);
const sourceValue = () => typeof state?.runtime?.source === 'object' ? state.runtime.source?.source ?? state.runtime.source?.url ?? 'Source metadata available' : state?.runtime?.source;
const runnable = () => available() && configured() && installed() && !state?.running;
const text = (node,value) => { node.textContent = value === null || value === undefined ? 'Not reported' : String(value); };
const element = (tag,cls,value) => {const node=document.createElement(tag);if(cls)node.className=cls;if(value!==undefined)text(node,value);return node;};
const short = value => typeof value==='string'&&value.length>52 ? value.slice(0,24)+'…'+value.slice(-20) : String(value??'Not reported');

function showError(message) {localError=message || '';renderBanner();}
function renderBanner() {
  const serverError=selected<3&&state?.lastRun&&String(state?.error||'').startsWith('Wallet funding required:')?'':state?.error;
  const message=localError || (typeof serverError==='string' ? serverError : serverError?.message) || '';
  $('error-banner').hidden=!message;text($('error-banner'),message);
}
function selectFromHash() {
  const index=steps.findIndex(step=>'#'+step.id===location.hash);
  selected=index<0?0:index;draft=null;draftDirty=false;render();
}
function selectStep(index) {location.hash=steps[Math.max(0,Math.min(steps.length-1,index))].id;}
function completed(index) {
  return [prepared(),configured(),installed(),hasRun(),false,false,state?.stage==='stopped'&&!state?.running][index];
}
function renderNavigation() {
  if(!$('steps').children.length) steps.forEach((step,index)=>{
    const button=element('button','step-tab');button.type='button';button.append(element('span','step-number',String(index+1).padStart(2,'0')),element('span','',step.label));button.onclick=()=>selectStep(index);$('steps').append(button);
  });
  [...$('steps').children].forEach((button,index)=>{button.classList.toggle('active',index===selected);button.classList.toggle('complete',completed(index));if(index===selected)button.setAttribute('aria-current','step');else button.removeAttribute('aria-current');});
  $('previous-step').disabled=selected===0;
  $('next-step').disabled=selected===steps.length-1 || (selected===1 && configPart<2);
  text($('next-step'),selected<steps.length-1?'Next: '+steps[selected+1].label.toLowerCase()+' →':'Final step');
}
function facts(rows) {
  const box=element('div','facts');for(const [label,value]of rows){const row=element('div','fact');row.append(element('span','',label),element('strong','',value));box.append(row);}return box;
}
function notice(message,warning=false) {return element('div','notice'+(warning?' warning':''),message);}
function button(label,callback,disabled=false,secondary=false) {
  const node=element('button','action'+(secondary?' secondary':''),label);node.type='button';node.disabled=Boolean(disabled);node.onclick=callback;return node;
}
function actionButton(action,label,allowed,secondary=false) {
  return button((pending===action||(action==='stop'&&stoppingPending))?label.replace(/\.$/,'')+'…':label,()=>perform(action),!allowed,secondary);
}
function copyButton(label,value){const b=button(label,async()=>{try{await navigator.clipboard.writeText(value);b.textContent='Copied';}catch{showError('Select and copy the displayed text.');}},false,true);return b;}
function fundingForm(wallet){
  const form=element('form','funding-form');
  const label=element('label','','Your email'),input=element('input');input.type='email';input.id='funding-email';input.required=true;input.maxLength=254;input.autocomplete='email';input.value=fundingEmail;label.htmlFor=input.id;input.oninput=()=>{fundingEmail=input.value;};
  const status=element('p','note','Checking registration…'),result=element('div','notice');result.hidden=true;result.setAttribute('role','status');
  const submit=element('button','action','Request workshop funds');submit.type='submit';submit.disabled=true;
  const retry=button('Check registration status',check,false,true);let open=false;
  form.append(label,input,status,submit,retry,result);
  if(fundingReceipt?.wallet===wallet){result.hidden=false;result.textContent=fundingReceipt.message;}
  async function check(){
    submit.disabled=true;
    try{const r=await fetch(FUNDING_API+'/api/status'+fundingQuery,{credentials:'omit',cache:'no-store',redirect:'error',signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error();const data=await r.json();open=data.state==='open';status.textContent=open?'Registration is accepting requests. The first 30 unique pairs get funded places; later pairs join the waitlist.':data.state==='closed'?'Registration has closed. Keep building; contact the host about funding.':'Registration is not accepting requests yet. Check again shortly.';submit.disabled=!open||fundingPending;}catch{status.textContent='Cannot reach registration. Check the connection and try again.';open=false;}
  }
  form.onsubmit=async event=>{
    event.preventDefault();if(!open||fundingPending||!form.reportValidity())return;
    const email=input.value.trim().toLowerCase();fundingEmail=email;fundingPending=true;submit.disabled=true;submit.textContent='Submitting…';result.hidden=true;
    try{const r=await fetch(FUNDING_API+'/api/register'+fundingQuery,{method:'POST',credentials:'omit',redirect:'error',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,address:wallet}),signal:AbortSignal.timeout(15000)});const data=await r.json();if(!r.ok)throw Error(data.error||'Registration could not be saved.');if(!['selected','waitlist'].includes(data.status)||!data.receipt)throw Error('No registration receipt returned. Retry with the same email and address.');const message=(data.status==='selected'?'Request received for funding review.':'You are on the funding waitlist.')+' No funds have been sent by this form. Receipt: '+data.receipt;fundingReceipt={wallet,email,message};result.textContent=message;result.hidden=false;
    }catch(error){result.textContent=error.message||'Connection interrupted. Retry with the same email and address.';result.hidden=false;}finally{fundingPending=false;submit.textContent='Request workshop funds';submit.disabled=!open;}
  };
  queueMicrotask(check);return form;
}
function configForm() {
  const form=element('form','config-form');form.id='strategy-config';form.autocomplete='off';
  const values=draft ?? state?.config ?? {};
  const fields=[['wallet','Public Sui wallet address','text','0x…'],['targetUsd','Desired Sui position value (USD)','number',''],['pollSeconds','Monitoring interval (seconds)','number',''],['lowPrice','Low price threshold (USD / Sui)','number',''],['highPrice','High price threshold (USD / Sui)','number','']];
  for(const [name,label,type,placeholder]of fields){
    const wrap=element('div','field'+(name==='wallet'?' full':'')),labelNode=element('label','',label),input=element('input');
    input.id='config-'+name;input.name=name;input.type=type;input.placeholder=placeholder;input.required=true;input.value=values[name]??'';input.disabled=Boolean(pending||state?.running||state?.busy);labelNode.htmlFor=input.id;
    if(type==='number'){input.step=name==='pollSeconds'?'1':'any';input.min=name==='pollSeconds'?'30':'0.000001';}
    else{input.spellcheck=false;input.maxLength=66;input.setAttribute('autocapitalize','none');}
    input.oninput=()=>{draftDirty=true;draft=readConfig(false);};wrap.append(labelNode,input);form.append(wrap);
  }
  const hint=element('p','field-hint field full','Desired position value is a strategy target, not a spending limit. Monitoring runs at least 30 seconds apart.');form.append(hint);
  form.onsubmit=event=>{event.preventDefault();if(available()&&prepared()&&!state?.running)perform('configure');};return form;
}
function readConfig(validate=true) {
  const form=$('strategy-config');if(!form)return null;
  if(validate&&!form.reportValidity())return null;
  const values=Object.fromEntries(['wallet','targetUsd','lowPrice','highPrice','pollSeconds'].map(name=>[name,form.elements.namedItem(name)?.value??'']));
  const config={wallet:String(values.wallet??'').trim(),targetUsd:Number(values.targetUsd),lowPrice:Number(values.lowPrice),highPrice:Number(values.highPrice),pollSeconds:Number(values.pollSeconds),network:'mainnet',dryRun:true};
  if(validate){
    if(!/^0x[0-9a-fA-F]{64}$/.test(config.wallet)||BigInt(config.wallet)<=15n){showError('Enter the full public Sui wallet address. No private key or recovery phrase.');return null;}
    if(![config.targetUsd,config.lowPrice,config.highPrice,config.pollSeconds].every(Number.isFinite)||config.targetUsd<=0||config.lowPrice<=0||config.highPrice<=config.lowPrice||config.pollSeconds<30||!Number.isInteger(config.pollSeconds)){showError('Use positive values, a high price above the low price, and a whole-number interval of at least 30 seconds.');return null;}
  }
  return config;
}
function renderPanel(force=false) {
  const key=JSON.stringify([selected,configPart,prepared(),configured(),installed(),state?.running,state?.busy,state?.stage,hasRun(),Boolean(available()),pending,stoppingPending]);
  if(!force&&key===panelKey)return;
  if(draftDirty&&$('strategy-config'))draft=readConfig(false);
  panelKey=key;const step=steps[selected],content=$('step-content'),actions=$('step-actions');content.replaceChildren();actions.replaceChildren();
  text($('step-eyebrow'),String(selected+1).padStart(2,'0')+' / '+step.label.toUpperCase());text($('step-title'),step.title);text($('step-description'),step.description);
  if(step.id==='prepare'){
    content.append(facts([['Console address',location.origin],['Node runtime',state?.runtime?.node??'Not checked'],['Recipe source',short(sourceValue())],['Runtime check',prepared()?'Passed':'Not completed']]));
    content.append(element('p','note',prepared()?'This runtime has already passed its checks. Check it again to repeat this step; agent installation is step 03.':'Click Check runtime. A successful check enables wallet setup; it does not install the agent.'));
    actions.append(actionButton('prepare',prepared()?'Check runtime again':'Check runtime',available()&&!state?.running));
  }else if(step.id==='configure'||step.id==='modify'){
    if(!prepared())content.append(notice('Prepare the runtime before saving configuration.',true));
    if(state?.running||state?.busy)content.append(notice('Stop the active process before changing the configuration.',true));
    if(step.id==='configure'){
      const subnav=element('nav','wallet-stages');subnav.setAttribute('aria-label','Wallet setup stages');
      ['Wallet','Strategy','Funding'].forEach((label,index)=>{const b=button((index+1)+'. '+label,()=>{if($('strategy-config')){draft=readConfig(false);draftDirty=true;}configPart=index;renderPanel(true);renderNavigation();},false,true);b.setAttribute('aria-current',index===configPart?'step':'false');subnav.append(b);});content.append(subnav);
      if(configPart===0){
        content.append(element('h3','setup-heading','Create or sign in to your wallet.'));
        content.append(element('p','note','Open a second terminal in the extracted kit folder. Run the wallet setup command below. Choose Create account for a new wallet, or Sign in for an existing account that already has a CLI password.'));
        const command=element('pre','wallet-command','node wallet-setup.mjs');content.append(command);
        actions.append(copyButton('Copy wallet setup command','node wallet-setup.mjs'));
        const list=element('ol','list');for(const line of ['Enter your own email and password in Terminal. The password stays hidden.','For a new account, approve the email while the setup command waits.','When setup succeeds, copy the Sui address it prints. Keep passwords and approval emails off the shared screen.'])list.append(element('li','',line));content.append(list);
        content.append(element('p','note','Already use the web wallet with an email link or social login? Keep using that wallet and copy its Sui mainnet receive address into Strategy. CLI Sign in requires a password; do not create another account to access an existing wallet. The console only reads the saved address.'));
        actions.append(button('Continue to strategy',()=>{configPart=1;renderPanel(true);renderNavigation();}));
      }else if(configPart===1){
        const historical=state?.runtime?.source?.historicalWallet?.address;
        if(historical&&state?.config?.wallet===historical)content.append(notice('This is a historical example address. Do not fund it. Replace it with the verified address of a wallet you control.',true));
        content.append(configForm());
        actions.append(actionButton('configure','Save and continue to funding',available()&&prepared()&&!state?.running));
      }else{
        const wallet=state?.config?.wallet,historical=state?.runtime?.source?.historicalWallet?.address;
        if(!configured()||!wallet||wallet===historical){content.append(notice('Save your own verified wallet address in Strategy before funding. Do not fund the historical example address.',true));actions.append(button('Back to strategy',()=>{configPart=1;renderPanel(true);renderNavigation();}));}
        else{
          content.append(element('h3','setup-heading','Fund the saved wallet.'));
          content.append(element('p','note','Compare this full address with the Sui address shown by wallet setup before receiving funds.'));
          content.append(element('pre','wallet-command',wallet));actions.append(copyButton('Copy saved wallet address',wallet));
          content.append(element('p','note','Enter the same email used for wallet setup. This request includes the saved Sui address above.'));
          content.append(fundingForm(wallet));

        }
      }
    }else{
      content.append(configForm());actions.append(actionButton('configure','Apply configuration',available()&&prepared()&&!state?.running));
    }
    if(state?.running||state?.busy||pending)actions.append(actionButton('stop','Stop active process',canStop(),true));
    if(step.id==='modify'&&configured()&&!state?.running)actions.append(button('Open run controls',()=>selectStep(3),false,true));
  }else if(step.id==='deploy'){
    content.append(facts([['Runtime',prepared()?'Prepared':'Preparation required'],['Strategy',configured()?'Configuration saved':'Configuration required'],['Dependencies',installed()?'Installed':'Not installed']]));
    content.append(element('pre','wallet-command','npm ci --ignore-scripts --no-audit --no-fund'));
    content.append(element('p','note','Click below and wait for installation to finish. Then go to Start / run and choose Run once. Installation does not start the agent.'));
    if(installed())content.append(notice('Dependencies are already installed on this runtime. Install again to repeat this step.'));
    actions.append(actionButton('deploy',installed()?'Install dependencies again':'Install dependencies',available()&&prepared()&&configured()&&!state?.running));
  }else if(step.id==='run'){
    content.append(facts([['Network',state?.config?.network??'Not reported'],['Mode',safeMode()?'Transaction dry-run':'Not verified'],['Desired position',state?.config?.targetUsd!==undefined?'$'+state.config.targetUsd:'Not configured'],['Monitoring',state?.running?'Running':state?.config?.pollSeconds?state.config.pollSeconds+' seconds between cycles':'Not configured']]));
    content.append(element('p','note','A cycle reads the pool and wallet, evaluates the strategy, and builds a route when its conditions and available balances allow. A dry-run does not submit a transaction.'));
    actions.append(actionButton('run','Run once',runnable()),actionButton('start',state?.running?'Monitoring active':'Start monitoring',runnable(),true));
  }else if(step.id==='inspect'){
    const list=element('ol','list');for(const item of ['Check the price and balances returned by mainnet.','Identify the proposed action or the reason no action was built.','Inspect the raw output and any reported transaction reference.'])list.append(element('li','',item));content.append(list);
    actions.append(button('Refresh result',()=>refresh(),refreshing||Boolean(pending)),button('Save output',downloadOutput,!hasRun(),true));
  }else if(step.id==='stop'){
    content.append(facts([['Monitoring',state?.running?'Running':'Not running'],['Last run',hasRun()?'Output retained':'No output received'],['Signing',safeMode()?'Disabled':'Mode not verified']]));
    if(state?.stage==='stopped')content.append(notice('The runtime is stopped. Its output and execution log remain available.'));
    actions.append(actionButton('stop','Stop agent',canStop()),button('Save output',downloadOutput,!hasRun(),true));
  }
}

function structuredRecords(value) {
  const records=[];let visited=0;
  function visit(item,depth=0){
    if(++visited>1000||depth>7||item===null||item===undefined)return;
    if(typeof item==='string'){
      for(const line of item.split('\n').slice(-100)){const trimmed=line.trim();if(trimmed.startsWith('{'))try{visit(JSON.parse(trimmed),depth+1);}catch{}}
    }else if(Array.isArray(item))item.slice(-100).forEach(child=>visit(child,depth+1));
    else if(typeof item==='object'){records.push(item);for(const [key,child]of Object.entries(item))if(!['txBytes','wallet','source'].includes(key)&&(typeof child==='object'||['stdout','output','logs','text'].includes(key)))visit(child,depth+1);}
  }
  visit(value);return records;
}
function number(value,max=6) {const n=Number(value);return value!==null&&value!==''&&Number.isFinite(n)?n.toLocaleString('en-US',{maximumFractionDigits:max}):String(value);}
function metric(label,value,unit='') {const node=element('div','metric'),strong=element('strong','',value);node.append(element('span','',label),strong);if(unit)strong.append(element('small','',unit));return node;}
// Describe the recorded run, never current settings that may have changed since it ran.
function describeDecision({price,proposal,unsigned,complete,funding,hold,inRange,failure}) {
  const direction=String(proposal?.direction||unsigned?.direction||'').toLowerCase();
  const title=complete?.outcome==='HOLD'?'HOLD':direction==='sell'?'SELL Sui':direction==='buy'?'BUY Sui':complete?.outcome?.startsWith('BLOCKED')?'BLOCKED':failure?'RUN FAILED':'Decision unavailable';
  let summary='The run has not reported a strategy decision.';
  if(direction==='sell')summary='Sui reached the high price threshold. Sell Sui for USDC to move its dollar value toward the strategy target.';
  else if(direction==='buy')summary='Sui reached the low price threshold. Use USDC to buy Sui and move its dollar value toward the strategy target.';
  if(complete?.outcome==='HOLD'){
    summary=inRange?'Sui is between your price thresholds. Keep the current Sui and USDC balances.':hold?.reason==='target_met'?'The Sui value already meets the strategy target. No purchase is needed.':'No Sui can be sold toward the target while keeping the gas reserve. Keep the current balances.';
  }
  if(complete?.outcome==='BLOCKED_GAS_RESERVE')summary='The wallet needs at least '+number(funding?.requiredSuiReserve??price?.gasReserveSui??0.02)+' Sui for the gas reserve before a swap can be prepared.';
  else if(complete?.outcome==='BLOCKED_CAPITAL')summary='The buy rule was reached, but the wallet does not have enough USDC for the minimum purchase.';
  let status='Dry run · incomplete',execution='No transaction was submitted. The run has not completed.';
  if(complete?.outcome==='SIMULATED_UNSIGNED'&&!failure){status='Dry run · passed';execution='Simulated on Sui mainnet. No swap was sent; wallet balances are unchanged.';}
  else if(complete?.outcome==='HOLD'&&!failure){status='Dry run · no trade';execution='Live mainnet data was read. No swap was needed or submitted.';}
  else if(complete?.outcome?.startsWith('BLOCKED')){status='Dry run · blocked';execution='No transaction was submitted. Resolve the funding requirement, then run again.';}
  else if(failure||complete?.outcome==='FAILED'){status='Dry run · failed';execution='No transaction was submitted. Check the error in Raw execution output.';}
  return {title,summary,status,execution};
}
function renderOutput() {
  const setup=selected<3;
  text($('output-eyebrow'),selected===2?'INSTALLATION':setup?'SETUP GUIDE':'EXECUTION OUTPUT');
  $('setup-output').hidden=!setup;
  $('raw-details').hidden=setup;$('output-footer').hidden=setup;
  if(setup){
    outputKey='';$('output-empty').hidden=true;$('output-content').hidden=true;
    text($('result-kind'),selected===2?'Installation':'Setup');
    text($('output-title'),selected===2?'Installation output.':selected===1?'Wallet → strategy → funding.':'Start here.');
    const box=$('setup-output');box.replaceChildren();
    if(selected===0){
      const list=element('ol','list');for(const line of ['Install Node 24 on the computer that will run the agent.','Download and unzip the Rebalancer kit.','In the extracted folder, run PORT='+location.port+' node server.mjs --open on Mac/Linux, or $env:PORT="'+location.port+'"; node server.mjs --open in PowerShell. Keep that terminal open.','This opens the console. Check runtime here, then complete step 02 and install the agent in step 03.'])list.append(element('li','',line));box.append(list);
      const guide=element('a','action secondary','Open installation guide ↗');guide.href='https://holonym-foundation.github.io/basecamp-builder-lab/deploy.html';guide.target='_blank';guide.rel='noopener';box.append(guide);
      box.append(element('p','note','Connected runtime: '+(state?.runtime?.host||'Not reported')+'. Checks and installs apply to that runtime. A Studio tunnel uses the Studio computer, not this laptop.'));
    }else if(selected===1){
      const list=element('ol','list');for(const line of ['Wallet: run the wallet setup helper and approve your email.','Strategy: paste the returned Sui address and save your settings.','Funding: register your email. The host verifies the wallet match before the payout.','Continue to Install agent. Run once after installation to inspect your actual balances.'])list.append(element('li','',line));box.append(list);
    }else{
      const install=(state?.events||[]).filter(e=>['deploy','install'].includes(e.operation));
      box.append(element('p','note',pending==='deploy'?'Installing dependencies now…':installed()?'Installed on this runtime. The entries below show actual installation events.':'No installation completed yet. Click Install dependencies.'));
      box.append(element('pre','install-output',install.length?install.map(e=>timeLabel(e.time)+'  '+e.message).join('\n'):'Installation output will appear here.'));
    }
    return;
  }
  const raw=hasRun()?JSON.stringify(state.lastRun,null,2):'';
  if(raw===outputKey)return;outputKey=raw;
  $('output-empty').hidden=hasRun();$('output-content').hidden=!hasRun();$('download-output').disabled=!hasRun();
  text($('raw-output'),raw?(raw.length>120000?raw.slice(0,120000)+'\n… Display shortened. Save output for the complete result.':raw):'No output received.');
  $('result-metrics').replaceChildren();$('explorer-links').replaceChildren();
  if(!hasRun()){text($('output-title'),'Awaiting a decision.');text($('result-kind'),'No run yet');return;}
  const records=structuredRecords(state.lastRun);
  const find=predicate=>records.filter(predicate).at(-1);
  const price=find(row=>row.message==='price_check');
  const proposal=find(row=>row.message==='rebalance_triggered');
  const unsigned=find(row=>row.message==='unsigned_swap_built');
  const complete=find(row=>row.message==='run_complete');
  const funding=find(row=>row.message==='funding_required');
  const hold=find(row=>row.message==='hold');
  const inRange=find(row=>row.message==='price_in_range');
  const failure=find(row=>row.level==='error'||row.error)||((state.lastRun.exitCode??state.lastRun.code)>0?state.lastRun:null);
  const decision=describeDecision({price,proposal,unsigned,complete,funding,hold,inRange,failure});
  text($('output-title'),decision.title);
  text($('result-summary'),decision.summary);
  text($('result-kind'),decision.status);
  text($('result-execution'),decision.execution);
  if(unsigned&&['buy','sell'].includes(unsigned.direction)){
    const selling=unsigned.direction==='sell';
    if(unsigned.amountInRaw!==undefined)$('result-metrics').append(metric('Proposed swap input',number(Number(unsigned.amountInRaw)/(selling?1e9:1e6)),selling?'Sui':'USDC'));
    if(unsigned.quotedOutRaw!==undefined)$('result-metrics').append(metric('Quoted swap output',number(Number(unsigned.quotedOutRaw)/(selling?1e6:1e9)),selling?'USDC':'Sui'));
  }
  if(price){
    if(price.price!==undefined)$('result-metrics').append(metric('Sui price',number(price.price),'USD / Sui'));
    if(price.targetBalance!==undefined)$('result-metrics').append(metric('Sui balance before run',number(price.targetBalance),'Sui'));
    if(price.targetValueUsd!==undefined)$('result-metrics').append(metric('Sui value before run','$'+number(price.targetValueUsd,2)));
    if(price.quoteBalance!==undefined)$('result-metrics').append(metric('USDC balance before run',number(price.quoteBalance),'USDC'));
  }
  if(funding?.requiredSuiReserve!==undefined)$('result-metrics').append(metric('Required Sui reserve',number(funding.requiredSuiReserve),'Sui'));
  const digests=new Set();for(const record of records.filter(row=>row.submitted===true||row.message==='rebalance_complete'||row.status==='confirmed'))for(const key of ['txHash','transactionDigest','digest']){const value=record[key];if(typeof value==='string'&&/^[1-9A-HJ-NP-Za-km-z]{32,64}$/.test(value))digests.add(value);}
  const checkpoint=find(row=>row.message==='chain_checkpoint');
  if(checkpoint&&/^\d+$/.test(String(checkpoint.checkpoint))){const link=element('a','','Inspect checkpoint '+checkpoint.checkpoint+' ↗');link.href='https://suiscan.xyz/mainnet/checkpoint/'+checkpoint.checkpoint;link.target='_blank';link.rel='noopener noreferrer';$('explorer-links').append(link);}
  for(const digest of [...digests].slice(0,4)){const link=element('a','','Inspect reported transaction ↗');link.href='https://suiscan.xyz/mainnet/tx/'+encodeURIComponent(digest);link.target='_blank';link.rel='noopener noreferrer';$('explorer-links').append(link);}
}
function timeLabel(value) {const date=new Date(value);return Number.isFinite(date.getTime())?date.toLocaleTimeString('en-GB',{hour12:false}):String(value??'—');}
function renderEvents() {
  $('events-panel').hidden=selected<2;
  const all=Array.isArray(state?.events)?state.events:[],events=selected===2?all.filter(e=>['deploy','install'].includes(e.operation)):all,key=JSON.stringify(events);
  if(key===eventKey)return;eventKey=key;
  const list=$('event-list'),atEnd=list.scrollHeight-list.scrollTop-list.clientHeight<35;list.replaceChildren();
  if(!events.length)list.append(element('li','no-events','Events appear only when reported by the runtime.'));
  for(const event of events.slice(-100)){
    const row=element('li','event-row'),status=String(event.status??'reported'),tone=/success|complete|done|ready|stopped/i.test(status)?' success':/error|fail/i.test(status)?' error':'';
    row.append(element('time','event-time',timeLabel(event.time)),element('span','event-operation',event.operation??'runtime'),element('span','event-status'+tone,status),element('span','event-message',typeof event.message==='string'?event.message:JSON.stringify(event.message??'')));list.append(row);
  }
  text($('event-count'),events.length?events.length+' reported event'+(events.length===1?'':'s'):'No events received');
  if(atEnd)list.scrollTop=list.scrollHeight;
}
function renderSource() {
  const holder=$('source-reference'),source=sourceValue();holder.replaceChildren();if(!source)return;
  let url;try{url=new URL(String(source),location.href);}catch{}
  if(url&&(['http:','https:'].includes(url.protocol))&&(/^(https?:\/\/|\/)/.test(String(source)))){const a=element('a','','Recipe source ↗');a.href=url.href;a.target='_blank';a.rel='noopener noreferrer';holder.append(a);}
  else text(holder,'Source: '+short(source));
}
function render() {
  renderNavigation();renderPanel();renderBanner();renderOutput();renderEvents();renderSource();
  text($('stage-label'),connected?(stageLabels[state?.stage]||state?.stage||'Status received'):'Runtime disconnected');
  $('connection-dot').className='status-dot '+(connected?'connected':'offline');
  text($('mode-label'),safeMode()?'Live mainnet · transaction dry-run':connected?'Runtime mode not verified':'Connecting to runtime');
  $('running-indicator').hidden=!state?.running;
  $('stop-runtime').hidden=!(state?.running||state?.busy||pending||stoppingPending);$('stop-runtime').disabled=!canStop();text($('stop-runtime'),stoppingPending?'Stopping…':'Stop process');
  text($('cost-label'),safeMode()?'Transaction gas: 0 Sui spent · signing disabled':'Signing mode not verified.');
}
async function session() {
  const response=await fetch('/api/session',{cache:'no-store',credentials:'same-origin',signal:AbortSignal.timeout(10000)});
  if(!response.ok)throw Error('Runtime controls are unavailable. Refresh the connection.');
  const data=await response.json();if(typeof data.token!=='string'||!data.token)throw Error('Runtime controls did not return a session.');token=data.token;
}
async function refresh() {
  if(refreshing)return;refreshing=true;
  try{
    const response=await fetch('/api/status',{cache:'no-store',credentials:'same-origin',signal:AbortSignal.timeout(10000)});
    if(!response.ok)throw Error('The runtime did not return its status.');
    const next=await response.json();if(!next||typeof next.stage!=='string'||!next.runtime||!next.config)throw Error('The runtime returned an incomplete status.');
    state=next;connected=true;text($('updated-at'),'Updated '+new Date().toLocaleTimeString('en-GB',{hour12:false}));
  }catch(error){connected=false;showError(error.message||'Cannot reach the runtime. Check the local connection, then refresh.');}
  finally{refreshing=false;render();}
}
async function perform(action) {
  const stopping=action==='stop';
  if(stopping?!canStop():!available())return;
  let config;if(action==='configure'){config=readConfig();if(!config)return;}
  if(stopping)stoppingPending=true;else pending=action;showError('');render();
  try{
    const response=await fetch('/api/action',{method:'POST',cache:'no-store',credentials:'same-origin',headers:{'Content-Type':'application/json','X-Workshop-Token':token},body:JSON.stringify({action,...(config?{config}:{})}),signal:AbortSignal.timeout(180000)});
    let result;try{result=await response.json();}catch{throw Error('The operation returned no readable result. Refresh runtime status before another action.');}
    if(!response.ok){if(response.status===401||response.status===403)token=null;throw Error(typeof result.error==='string'?result.error:result.error?.message||'The runtime could not complete this operation.');}
    if(action==='configure'){draft=null;draftDirty=false;if(selected===1)configPart=2;}
  }catch(error){showError(error.name==='TimeoutError'||error.name==='AbortError'?'The request was interrupted. Check the execution log and refresh runtime status before another action.':error.message||'The request was interrupted. Check runtime status.');}
  finally{if(stopping)stoppingPending=false;else if(pending===action)pending=null;await refresh();renderPanel(true);}
}
function downloadOutput() {
  if(!hasRun())return;
  const data={savedAt:new Date().toISOString(),network:state.config.network,dryRun:state.config.dryRun,config:state.config,lastRun:state.lastRun};
  const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)+'\n'],{type:'application/json'})),link=element('a');link.href=url;link.download='sui-rebalancer-output-'+new Date().toISOString().replace(/[:.]/g,'-')+'.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
$('stop-runtime').onclick=()=>perform('stop');
$('previous-step').onclick=()=>selectStep(selected-1);$('next-step').onclick=()=>selectStep(selected+1);$('download-output').onclick=downloadOutput;
$('refresh-status').onclick=async()=>{showError('');if(!token)try{await session();}catch(error){showError(error.message);}await refresh();};
window.addEventListener('hashchange',selectFromHash);
selectFromHash();
try{await session();}catch(error){showError(error.message);}
await refresh();setInterval(refresh,3000);
