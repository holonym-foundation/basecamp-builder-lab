# Basecamp standalone Sui Rebalancer

Runs the public WaaP Rebalancer strategy against a public wallet on Sui mainnet. The operator console invokes an isolated recipe process and shows its actual JSONL output. It does not use AEX runtime state or wallet credentials.

Node 24 is required. Check `node --version` for v24.x, not v26. After installing Node 24, open a new Terminal and check again.

On Mac, unzip the kit, open Terminal, and run this if the folder is in Downloads:

```sh
cd ~/Downloads/sui-rebalancer && PORT=8788 node server.mjs --open
```

For another location, type `cd `, drag the extracted folder into Terminal, press Return, then run `PORT=8788 node server.mjs --open`. Keep Terminal open while using the console. `Start.command` is an optional double-click launcher; if macOS cannot verify it, dismiss the dialog and use the Terminal command to run the source directly. Typing `start.command` alone does not find a file in the current directory. On Windows, open `Start.cmd`, or run `$env:PORT="8788"; node server.mjs --open` from PowerShell in the extracted folder.

The browser opens http://127.0.0.1:8788. If a Rebalancer console is already there, the launcher reuses it without starting a second process. That console may be connected to Studio through a tunnel. It never stops another service. An older kit may show `EADDRINUSE`; open the same URL to check the existing console.

## Choose the console port

Use **8788** for the existing/default console. Use **8789** for a separate local rehearsal alongside it. Select the same port in the public build guide or presenter companion; this also updates deck console links in that browser. The server does not move when you change the guide selector.

From a fresh extracted kit folder, on Mac/Linux:

```sh
PORT=8789 node server.mjs --open
```

If your default Node is v26, use Node24 explicitly:

```sh
PORT=8789 npx --yes --package=node@24 -- node server.mjs --open
```

On Windows PowerShell:

```powershell
$env:PORT="8789"; node server.mjs --open
```

Open http://127.0.0.1:8789. Keep Terminal open. Port numbers do not isolate saved configuration: extract a separate folder to rehearse from the beginning. Do not run two instances against the same kit folder. A port conflict does not require stopping the existing console. Both workshop ports support the public funding form.

The console walks through Check runtime, Wallet + configure, Install agent, Run/Start and Stop. The installation button runs `npm ci --ignore-scripts --no-audit --no-fund` against the pinned recipe lockfile; configuration is saved only in the ignored `state/` directory. An empty wallet correctly returns an insufficient-capital outcome.

The console listens only on loopback. For Studio access, forward its port with `ssh -N -L 8788:127.0.0.1:8788 mac-studio-nj` and open the same local URL. Do not expose this operator endpoint on a public interface. API actions require a same-origin request and an in-memory session token.

The installed recipe is restricted to transaction building/simulation. It contains no signer or transaction submission capability. Successful reads, route construction, simulation and a signed transaction receipt are distinct milestones; inspect the reported output before describing what completed. Actual funded execution requires a separately reviewed wallet and exact action.

Source provenance is retained in `recipe/SOURCE.json`; the public recipe guide is https://docs.waap.human.tech/recipes/sui-portfolio-rebalancer. This guide’s high/low price thresholds and dollar-denominated Sui target differ from the older browser percentage-allocation exercise.

## Wallet setup and funding (step 02)

In the console, open **Wallet + configure → Wallet**. Open a second terminal in this kit folder and run:

```sh
node wallet-setup.mjs
```

If you already use a web wallet with email-link or social login, copy its Sui mainnet receive address and skip the CLI wallet helper. The console only needs that public address. CLI Sign in requires a password; it does not reuse a browser session. Do not sign up again to access an existing account.

Choose Create account for a new WaaP account, Sign in for an existing account with a password, or Show current account to repeat the address check. Enter your own email and password locally; passwords are hidden and never passed as command arguments. Complete any email approval while the command waits. The session stays in the private `.wallet-session/` folder, excluded from the distributed kit. This helper never transfers funds.

Copy the printed Sui address into **Strategy**, set the parameters, and save. In **Funding**, match the full saved address with your wallet and enter your email. The console includes the saved address automatically. The Funding QR offers the same form with email and address fields. No workshop code is required. Registration is first come, first served: the first 30 unique email-and-wallet pairs get funded places and the rest join the waitlist. A 15-minute reminder does not gate submission; the host reviews the export and distributes the measured allowance separately. A registration receipt is not a payment receipt. Check your wallet funding before the first funded run. Existing installations may display a historical observation address: never fund that example.
