# Basecamp standalone Sui Rebalancer

Runs the public WaaP Rebalancer strategy against a public wallet on Sui mainnet. The operator console invokes an isolated recipe process and shows its actual JSONL output. It does not use AEX runtime state or wallet credentials.

Node 24 is required. Run `node server.mjs`, then open http://127.0.0.1:8788. The console walks through Prepare, Configure, Deploy, Run/Start and Stop. Deploy installs the pinned recipe lockfile; configuration is saved only in the ignored `state/` directory. An empty wallet correctly returns an insufficient-capital outcome.

The console listens only on loopback. For Studio access, forward its port with `ssh -N -L 8788:127.0.0.1:8788 mac-studio-nj` and open the same local URL. Do not expose this operator endpoint on a public interface. API actions require a same-origin request and an in-memory session token.

The installed recipe is restricted to transaction building/simulation. It contains no signer or transaction submission capability. Successful reads, route construction, simulation and a signed transaction receipt are distinct milestones; inspect the reported output before describing what completed. Actual funded execution requires a separately reviewed wallet and exact action.

Source provenance is retained in `recipe/SOURCE.json`; the public recipe guide is https://docs.waap.human.tech/recipes/sui-portfolio-rebalancer. This guide’s high/low price thresholds and dollar-denominated SUI target differ from the older browser percentage-allocation exercise.
