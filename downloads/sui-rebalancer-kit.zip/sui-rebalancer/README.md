# Basecamp standalone Sui Rebalancer

Runs the public WaaP Rebalancer strategy against a public wallet on Sui mainnet. The operator console invokes an isolated recipe process and shows its actual JSONL output. It does not use AEX runtime state or wallet credentials.

Node 24 is required. Check `node --version` for v24.x, not v26. After installing Node 24, open a new Terminal and check again.

On Mac, unzip the kit, open Terminal, and run this if the folder is in Downloads:

```sh
cd ~/Downloads/sui-rebalancer && node server.mjs --open
```

For another location, type `cd `, drag the extracted folder into Terminal, press Return, then run `node server.mjs --open`. Keep Terminal open while using the console. `Start.command` is an optional double-click launcher; if macOS cannot verify it, dismiss the dialog and use the Terminal command to run the source directly. Typing `start.command` alone does not find a file in the current directory. On Windows, open `Start.cmd`, or run `node server.mjs --open` from a terminal in the extracted folder.

The browser opens http://127.0.0.1:8788. If a Rebalancer console is already there, the launcher reuses it without starting a second process. That console may be connected to Studio through a tunnel. It never stops another service. An older kit may show `EADDRINUSE`; open the same URL to check the existing console.

The console walks through Check runtime, Wallet + configure, Install agent, Run/Start and Stop. The installation button runs `npm ci --ignore-scripts --no-audit --no-fund` against the pinned recipe lockfile; configuration is saved only in the ignored `state/` directory. An empty wallet correctly returns an insufficient-capital outcome.

The console listens only on loopback. For Studio access, forward its port with `ssh -N -L 8788:127.0.0.1:8788 mac-studio-nj` and open the same local URL. Do not expose this operator endpoint on a public interface. API actions require a same-origin request and an in-memory session token.

The installed recipe is restricted to transaction building/simulation. It contains no signer or transaction submission capability. Successful reads, route construction, simulation and a signed transaction receipt are distinct milestones; inspect the reported output before describing what completed. Actual funded execution requires a separately reviewed wallet and exact action.

Source provenance is retained in `recipe/SOURCE.json`; the public recipe guide is https://docs.waap.human.tech/recipes/sui-portfolio-rebalancer. This guide’s high/low price thresholds and dollar-denominated SUI target differ from the older browser percentage-allocation exercise.

## Wallet setup and funding (step 02)

In the console, open **Wallet + configure → Wallet**. Open a second terminal in this kit folder and run:

```sh
node wallet-setup.mjs
```

Choose Create account for a new WaaP account, Sign in for an existing account, or Show current account to repeat the address check. Enter your own email and password locally; passwords are hidden and never passed as command arguments. Complete any email approval while the command waits. The session stays in the private `.wallet-session/` folder, excluded from the distributed kit. This helper never transfers funds.

Copy the printed Sui address into **Strategy**, set the parameters, and save. In **Funding**, match the full saved address with your wallet and enter your email. The console includes the saved address automatically. The Funding QR offers the same form with email and address fields. No workshop code is required. Registration is open for 15 minutes; the host reviews the export and distributes the measured allowance separately. A registration receipt is not a payment receipt. Check your wallet funding before the first funded run. Existing installations may display a historical observation address: never fund that example.
