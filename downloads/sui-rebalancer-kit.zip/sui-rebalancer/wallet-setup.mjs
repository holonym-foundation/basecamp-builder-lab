#!/usr/bin/env node
// Local account setup only. No funding, transaction or password persistence.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import readline from 'node:readline';

const KIT_ROOT=path.dirname(fileURLToPath(import.meta.url));
const PACKAGE='@human.tech/waap-cli@2.2.1';
const phases={registration_starting:'Requesting account registration…',registration_approval_sent:'Approval email sent. Open your inbox and approve this registration.',registration_waiting_for_approval:'Waiting for your email approval…',registration_approved:'Email approved. Creating the wallet…',logging_in:'Signing in…',authenticated:'Signed in. Checking wallet identity…'};
const validEmail=value=>typeof value==='string'&&/^[^\s@\x00-\x1f]+@[^\s@\x00-\x1f]+\.[^\s@\x00-\x1f]+$/.test(value)&&value.length<=254;
const sameEmail=(a,b)=>typeof a==='string'&&typeof b==='string'&&a.toLowerCase()===b.toLowerCase();
export function cliInvocation(platform=process.platform,execPath=process.execPath,exists=fs.existsSync){
  if(platform!=='win32')return {command:'npx',prefix:['--yes',PACKAGE]};
  // Windows .cmd files require a shell. Invoke npm's JS entry with Node instead;
  // email/password never enter cmd.exe quoting or command substitution.
  const npmEntry=path.join(path.dirname(execPath),'node_modules','npm','bin','npx-cli.js');
  if(!exists(npmEntry))throw Error('Cannot locate npm next to Node. Install Node with npm, then try again.');
  return {command:execPath,prefix:[npmEntry,'--yes',PACKAGE]};
}
export function createRunner({sessionDir,spawnImpl=spawn,onProgress=()=>{},invocation=cliInvocation()}={}){
  return function run(command,args=[],password){
    if(!['session-info','whoami','signup','login'].includes(command))throw Error('Unsupported account command');
    return new Promise((resolve,reject)=>{
      const child=spawnImpl(invocation.command,[...invocation.prefix,'--json',command,...args],{shell:false,detached:process.platform!=='win32',stdio:['pipe','pipe','pipe'],env:{...process.env,WAAP_CLI_ENV:'production',SILK_NODE_ENV:'production',WAAP_CLI_SESSION_DIR:sessionDir}});
      let buffer='',result=null,errorCode=null,settled=false,bytes=0;
      function line(raw){let value;try{value=JSON.parse(raw);}catch{return;}if(value.event==='result')result=value;if(value.event==='error'&&typeof value.code==='string')errorCode=value.code;if(value.event==='phase'&&phases[value.stage])onProgress(phases[value.stage]);}
      function stopChild(){if(process.platform!=='win32'&&child.pid){try{process.kill(-child.pid,'SIGTERM');return;}catch{}}child.kill('SIGTERM');}
      const timer=setTimeout(()=>{stopChild();finish(Error('Account setup timed out. For a pending registration, choose Resume email approval.'));},command==='signup'?12*60*1000:120000);
      function finish(error,value){if(settled)return;settled=true;clearTimeout(timer);process.removeListener('SIGINT',cancel);if(error)reject(error);else resolve(value);}
      function cancel(){stopChild();finish(Error('Cancelled. Your saved session was not intentionally cleared.'));}
      process.once('SIGINT',cancel);
      child.on('error',()=>finish(Error('Could not start pinned WaaP CLI. Check that Node and npm are installed.')));
      child.stdout.on('data',chunk=>{bytes+=chunk.length;if(bytes>1024*1024){stopChild();finish(Error('Unexpected CLI output; stopped without displaying it.'));return;}buffer+=chunk.toString();let i;while((i=buffer.indexOf('\n'))>=0){line(buffer.slice(0,i));buffer=buffer.slice(i+1);}});
      // Never forward untrusted CLI error strings: a backend might echo input.
      child.stderr.on('data',()=>{});
      child.stdin.on('error',()=>{});
      child.on('close',(code,signal)=>{if(buffer.trim())line(buffer);finish(null,{ok:code===0&&!signal,result,code,errorCode});});
      child.stdin.end(password===undefined?'':password+'\n');
      password=undefined;
    });
  };
}
function ensurePrivateDirectory(dir){
  if(fs.existsSync(dir)){const info=fs.lstatSync(dir);if(!info.isDirectory()||info.isSymbolicLink())throw Error('Wallet session path must be a private directory, not a symlink.');}
  else fs.mkdirSync(dir,{mode:0o700});
  if(process.platform!=='win32')fs.chmodSync(dir,0o700);
  for(const name of ['session.json','pending-registration.json']){const file=path.join(dir,name);if(fs.existsSync(file)&&fs.lstatSync(file).isSymbolicLink())throw Error('Refusing a linked wallet session file.');}
}
export async function runSetup({root=KIT_ROOT,ask,secret,progress=()=>{},writeResult=()=>{},runnerFactory=createRunner}={}){
  const sessionDir=path.join(root,'.wallet-session');ensurePrivateDirectory(sessionDir);
  const lock=path.join(sessionDir,'.setup.lock');let fd;
  try{fd=fs.openSync(lock,'wx',0o600);}catch{throw Error('Another wallet setup may be running. Finish it before starting this one.');}
  try{
    fs.writeFileSync(fd,String(process.pid));
    const run=runnerFactory({sessionDir,onProgress:progress});
    const choice=(await ask('1 Create account\n2 Sign in\n3 Show current wallet\n4 Resume email approval\nChoose [1–4]: ')).trim();
    if(!['1','2','3','4'].includes(choice))throw Error('Choose 1, 2, 3 or 4.');
    const sessionExists=fs.existsSync(path.join(sessionDir,'session.json'));
    const prior=sessionExists?await run('session-info'):{ok:false};
    const priorEmail=prior.ok&&validEmail(prior.result?.email)?prior.result.email:null;
    let expectedEmail;
    if(choice==='3'){
      if(!sessionExists)throw Error('No workshop session yet. Choose Create account or Sign in.');
      expectedEmail=priorEmail;
    }else{
      const raw=(await ask('Account email: ')).trim();if(!validEmail(raw))throw Error('Enter a valid email address.');expectedEmail=raw;
      if(sessionExists&&!sameEmail(priorEmail,expectedEmail)){
        const label=priorEmail||'an unverified existing account';
        const confirmation=await ask(`This folder holds ${label}. Replace its local session with ${expectedEmail}? Type REPLACE to continue: `);
        if(confirmation.trim()!=='REPLACE')throw Error('Cancelled. Existing session preserved.');
      }
      let args=[],command;
      if(choice==='4'){
        const pendingFile=path.join(sessionDir,'pending-registration.json');
        if(!fs.existsSync(pendingFile))throw Error('No pending registration. Choose Create account or Sign in.');
        // Read only the email field for identity matching; never display pending secrets.
        let pending;try{pending=JSON.parse(fs.readFileSync(pendingFile,'utf8'));}catch{throw Error('Pending registration cannot be read.');}
        if(!sameEmail(pending.email,expectedEmail))throw Error('Pending registration belongs to another email. Enter that email to resume.');
        pending=null;command='signup';args=['--resume'];
      }else{
        command=choice==='1'?'signup':'login';
        let password=await secret(choice==='1'?'New password (hidden): ':'Password (hidden): ');
        if(choice==='1'&&!/^[A-Za-z0-9_.,:/+=@-]{12,64}$/.test(password))throw Error('New passwords need 12–64 characters: letters, numbers or -_.,:/+=@.');
        if(!password||/[\r\n\0]/.test(password))throw Error('Enter a nonempty, single-line password.');
        args=['--email',expectedEmail,'--password-stdin'];
        progress(choice==='1'?'Starting registration. Keep this window open while approving the email.':'Signing in to the workshop account…');
        const auth=await run(command,args,password);password=undefined;
        if(!auth.ok)throw Error(choice==='1'?'Registration did not complete. Approve the email, then choose Resume email approval; if the account already exists, choose Sign in.':'Sign-in did not complete. Check the email and password, then try again.');
      }
      if(choice==='4'){progress('Resuming email approval. Keep this window open.');const auth=await run(command,args);if(!auth.ok)throw Error('Registration did not complete. Check the approval email; an expired request needs a fresh registration.');}
    }
    progress('Verifying the saved account and Sui wallet…');
    const checked=await run('whoami');const result=checked.result;
    if(!checked.ok||!validEmail(result?.email)||!/^0x[0-9a-fA-F]{64}$/.test(result?.suiWalletAddress??''))throw Error('Could not verify the account email and Sui wallet. No wallet address was accepted.');
    if(expectedEmail&&!sameEmail(result.email,expectedEmail))throw Error('Saved account does not match the requested email. Stop and inspect the local session before funding.');
    const safe={email:result.email,suiWalletAddress:result.suiWalletAddress};writeResult(safe);return safe;
  }finally{if(fd!==undefined)fs.closeSync(fd);fs.unlinkSync(lock);}
}
function askLine(prompt){return new Promise(resolve=>{const rl=readline.createInterface({input:process.stdin,output:process.stderr,historySize:0});rl.question(prompt,answer=>{rl.close();resolve(answer);});});}
function hiddenPassword(prompt){
  if(!process.stdin.isTTY||typeof process.stdin.setRawMode!=='function')throw Error('Run this setup in an interactive terminal so the password can be hidden.');
  process.stderr.write(prompt);
  return new Promise((resolve,reject)=>{let chars=[];const wasRaw=process.stdin.isRaw;process.stdin.setRawMode(true);process.stdin.resume();
    function done(error){process.stdin.off('data',onData);process.stdin.setRawMode(Boolean(wasRaw));process.stdin.pause();process.stderr.write('\n');const value=chars.join('');chars=[];error?reject(error):resolve(value);}
    function onData(chunk){for(const char of chunk.toString('utf8')){if(char==='\r'||char==='\n'){done();return;}if(char==='\x03'){done(Error('Cancelled.'));return;}if(char==='\x7f'||char==='\b')chars.pop();else if(char>=' '&&char!=='\x1b')chars.push(char);if(chars.length>4096){done(Error('Password input is too long.'));return;}}}
    process.stdin.on('data',onData);
  });
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  if(!process.stdin.isTTY){process.stderr.write('Open an interactive terminal and run: node wallet-setup.mjs\n');process.exitCode=1;}
  else runSetup({ask:askLine,secret:hiddenPassword,progress:text=>process.stderr.write(text+'\n'),writeResult:value=>process.stdout.write(JSON.stringify(value)+'\n')}).catch(error=>{process.stderr.write(error.message+'\n');process.exitCode=1;});
}
