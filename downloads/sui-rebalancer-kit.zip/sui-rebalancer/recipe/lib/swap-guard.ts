// lib/swap-guard.ts — slippage and minimum-output checks. Pure functions, no SDK, so the
// money math can be read and tested on its own.
 
/** The Cetus SDKs take slippage as a fraction: 0.005 = 0.5%. 50 bps -> 0.005. */
export function slippageFraction(bps: number): number {
  if (!Number.isInteger(bps) || bps < 1 || bps > 500) {
    throw new Error(`SLIPPAGE_BPS must be a whole number from 1 to 500 (0.01%–5%), got ${bps}`)
  }
  return bps / 10_000
}
 
/** The least output (raw units) the agent will accept, given what the pool price says it should get. */
export function minAmountOut(expectedOutRaw: bigint, bps: number): bigint {
  slippageFraction(bps)
  return (expectedOutRaw * BigInt(10_000 - bps)) / 10_000n
}
 
/** Refuse a route whose quoted output is already worse than the pool price allows. */
export function checkQuote(quotedOutRaw: bigint, expectedOutRaw: bigint, bps: number): void {
  const min = minAmountOut(expectedOutRaw, bps)
  if (quotedOutRaw < min) {
    throw new Error(`route quote ${quotedOutRaw} is below the minimum ${min} (pool price ${expectedOutRaw}, ${bps} bps)`)
  }
}
 
/**
 * The slippage to hand the aggregator for the on-chain limit. The SDK sets the transaction's
 * minimum output to quote × (1 − slippage). Passing the full budget again would let the
 * two checks compound to about twice the budget, so this narrows it until the on-chain
 * minimum is no lower than minAmountOut. Rounded down: a smaller slippage only raises the floor.
 */
export function onChainSlippage(quotedOutRaw: bigint, expectedOutRaw: bigint, bps: number): number {
  const min = minAmountOut(expectedOutRaw, bps)
  const room = Number(quotedOutRaw - min) / Number(quotedOutRaw)
  return Math.floor(Math.max(0, Math.min(slippageFraction(bps), room)) * 1e9) / 1e9
}
