import test from 'node:test'
import assert from 'node:assert/strict'
import {slippageFraction, minAmountOut, checkQuote, onChainSlippage} from './swap-guard'
test('basis points use fraction without 100x error',()=>{assert.equal(slippageFraction(50),0.005);assert.equal(slippageFraction(500),0.05)})
test('invalid slippage refuses rather than loosens budget',()=>{for(const n of [0,-1,501,50.5,NaN,Infinity])assert.throws(()=>slippageFraction(n))})
test('minimum output floors only fractional raw units',()=>{assert.equal(minAmountOut(450_000_000n,50),447_750_000n);assert.equal(minAmountOut(101n,50),100n)})
test('quote below floor refuses',()=>{assert.throws(()=>checkQuote(447_749_999n,450_000_000n,50));assert.doesNotThrow(()=>checkQuote(447_750_000n,450_000_000n,50))})
test('pool-price and router slippage do not compound',()=>{const expected=450_000_000n, quote=449_000_000n;const fraction=onChainSlippage(quote,expected,50);assert.ok(fraction<0.005);assert.ok(Number(quote)*(1-fraction)>=Number(minAmountOut(expected,50)));assert.equal(onChainSlippage(447_750_000n,expected,50),0)})
