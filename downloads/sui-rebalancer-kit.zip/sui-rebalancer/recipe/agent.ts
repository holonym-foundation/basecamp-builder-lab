// agent.ts (part 1 of 6) — clients
import { config } from 'dotenv'
import { SuiGrpcClient } from '@mysten/sui/grpc'
import { Transaction } from '@mysten/sui/transactions'
import { normalizeStructTag } from '@mysten/sui/utils'
import CetusClmmSDK from '@cetusprotocol/sui-clmm-sdk'
import { AggregatorClient, Env } from '@cetusprotocol/aggregator-sdk'
import BN from 'bn.js'
import { createHash } from 'node:crypto'
import { checkQuote, onChainSlippage, slippageFraction } from './lib/swap-guard'
 
config({ quiet: true, path: process.env.RECIPE_ENV_FILE ?? '.env' })   // keep stdout pure JSONL
 
function requireEnv(name: string): string {
  const v = process.env[name]?.trim()
  if (!v) throw new Error(`${name} is required — see Environment Variables`)
  return v
}
 
const NETWORK = 'mainnet' as const
if (process.env.NETWORK && process.env.NETWORK !== 'mainnet') throw Error('This recipe is verified for mainnet reads only')
// A Sui gRPC endpoint. Every read and every transaction build goes through this one client.
const SUI_RPC = process.env.SUI_RPC ?? `https://fullnode.${NETWORK}.sui.io:443`
 
const sui = new SuiGrpcClient({ network: NETWORK, baseUrl: SUI_RPC })
const cetus = CetusClmmSDK.createSDK({ env: NETWORK, sui_client: sui })
 
// Created in main(), once the wallet address is known: the aggregator uses it to find the
// wallet's coins and to deliver the swap output. It never holds a key.
let aggregator: AggregatorClient
function initAggregator(owner: string) {
  aggregator = new AggregatorClient({
    signer: owner,
    client: sui,
    env: NETWORK === 'mainnet' ? Env.Mainnet : Env.Testnet,
    endpoint: process.env.CETUS_AGGREGATOR_URL,   // unset: the SDK's default router
  })
}

// agent.ts (part 2 of 6) — pool price
const CETUS_POOL_ID = requireEnv('CETUS_POOL_ID')
const TARGET_TOKEN_TYPE = normalizeStructTag(requireEnv('TARGET_TOKEN_TYPE'))
const QUOTE_TOKEN_TYPE = normalizeStructTag(requireEnv('QUOTE_TOKEN_TYPE'))
 
const decimalsCache = new Map<string, number>()
async function getDecimals(coinType: string): Promise<number> {
  const cached = decimalsCache.get(coinType)
  if (cached !== undefined) return cached
  const { coinMetadata } = await sui.getCoinMetadata({ coinType })
  if (!coinMetadata) throw new Error(`no coin metadata for ${coinType}`)
  decimalsCache.set(coinType, coinMetadata.decimals)
  return coinMetadata.decimals
}
 
/** Price of one target token in quote tokens, from the pool's current_sqrt_price. */
async function getPoolPrice(): Promise<number> {
  const pool = await cetus.Pool.getPool(CETUS_POOL_ID, true)
  const typeA = normalizeStructTag(pool.coin_type_a)
  const typeB = normalizeStructTag(pool.coin_type_b)
  const targetIsA = typeA === TARGET_TOKEN_TYPE
  if (!targetIsA && typeB !== TARGET_TOKEN_TYPE) throw new Error(`pool ${CETUS_POOL_ID} does not hold ${TARGET_TOKEN_TYPE}`)
  if ((targetIsA ? typeB : typeA) !== QUOTE_TOKEN_TYPE) throw new Error(`pool ${CETUS_POOL_ID} does not pair with ${QUOTE_TOKEN_TYPE}`)
 
  // Cetus stores sqrt(price) * 2^64. price of A in B = (sqrtPriceX64 / 2^64)^2 * 10^(decimalsA - decimalsB)
  const sqrt = Number(BigInt(pool.current_sqrt_price)) / 2 ** 64
  const priceAinB = sqrt * sqrt * 10 ** ((await getDecimals(typeA)) - (await getDecimals(typeB)))
  return targetIsA ? priceAinB : 1 / priceAinB
}

// agent.ts (part 3 of 6) — balances
async function getTokenBalance(owner: string, coinType: string): Promise<number> {
  const { balance } = await sui.getBalance({ owner, coinType })
  return Number(balance.balance) / 10 ** (await getDecimals(coinType))
}

// agent.ts (part 4 of 6) — route and build the swap
const SLIPPAGE_BPS = Number(process.env.SLIPPAGE_BPS ?? '50')
const SLIPPAGE = slippageFraction(SLIPPAGE_BPS)   // 50 bps -> 0.005; throws on a bad value at start-up
const GAS_RESERVE_SUI = Number(process.env.GAS_RESERVE_SUI ?? '0.02')
const MAX_TRADE_USD = Number(process.env.MAX_TRADE_USD ?? '1')
const DRY_RUN = true
if (process.env.DRY_RUN !== '1') throw Error('This deployment requires DRY_RUN=1; signing is not installed')
 
async function executeSwap(owner: string, direction: 'buy' | 'sell', amountUsd: number, price: number): Promise<SendOutcome | null> {
  const [from, target] = direction === 'sell' ? [TARGET_TOKEN_TYPE, QUOTE_TOKEN_TYPE] : [QUOTE_TOKEN_TYPE, TARGET_TOKEN_TYPE]
  const fromDecimals = await getDecimals(from)
  const targetDecimals = await getDecimals(target)
 
  // Selling: amountUsd of target tokens in, quote out. Buying: amountUsd of quote in, target out.
  const amountIn = direction === 'sell' ? amountUsd / price : amountUsd
  const expectedOut = direction === 'sell' ? amountIn * price : amountIn / price
  const amountInRaw = BigInt(Math.floor(amountIn * 10 ** fromDecimals))
  const expectedOutRaw = BigInt(Math.floor(expectedOut * 10 ** targetDecimals))
 
  const router = await aggregator.findRouters({ from, target, amount: new BN(amountInRaw.toString()), byAmountIn: true, slippage: SLIPPAGE })
  if (!router || router.error || router.insufficientLiquidity || router.paths.length === 0) {
    throw new Error(`Cetus aggregator found no route from ${from} to ${target}${router?.error ? `: ${router.error.msg}` : ''}`)
  }
 
  // The SDK's own limit is relative to the route's quote. This one is relative to the pool
  // price, so a route that is already bad cannot pass on its own say-so.
  const quotedOutRaw = BigInt(router.amountOut.toString())
  checkQuote(quotedOutRaw, expectedOutRaw, SLIPPAGE_BPS)
 
  log('info', 'route_quoted', { direction, amountInRaw: String(amountInRaw), expectedOutRaw: String(expectedOutRaw), quotedOutRaw: String(quotedOutRaw), paths: router.paths.length, slippageBps: SLIPPAGE_BPS })
  const tx = new Transaction()
  tx.setSender(owner)
  await aggregator.fastRouterSwap({
    router,
    txb: tx,
    slippage: onChainSlippage(quotedOutRaw, expectedOutRaw, SLIPPAGE_BPS),
    refreshAllCoins: true,
  })
 
  // waap-cli takes Sui transaction-kind bytes and adds gas itself.
  const txBytes = Buffer.from(await tx.build({ client: sui, onlyTransactionKind: true })).toString('base64')
  if (DRY_RUN) {
    const kindPath = path.join(path.dirname(LOG_FILE), `unsigned-kind-${Date.now()}.base64`)
    fs.writeFileSync(kindPath, txBytes + '\n', { mode: 0o600 })
    log('info', 'unsigned_swap_built', { direction, amountInRaw: String(amountInRaw), expectedOutRaw: String(expectedOutRaw), quotedOutRaw: String(quotedOutRaw), kindBytes: Buffer.from(txBytes, 'base64').length, artifact: kindPath, sha256: createHash('sha256').update(Buffer.from(txBytes, 'base64')).digest('hex'), submitted: false })
    const fullBytes = await tx.build({ client: sui })
    const simulation = await sui.simulateTransaction({ transaction: fullBytes, checksEnabled: true, include: { effects: true, balanceChanges: true, transaction: true }, signal: AbortSignal.timeout(20000) })
    const result = simulation.Transaction ?? simulation.FailedTransaction
    log(simulation.$kind === 'Transaction' ? 'info' : 'error', 'swap_simulation', { outcome: simulation.$kind, status: result?.status, effects: result?.effects, balanceChanges: result?.balanceChanges, unsignedTransactionSha256: createHash('sha256').update(fullBytes).digest('hex'), submitted: false, receipt: null })
    if (simulation.$kind !== 'Transaction') throw Error('Unsigned simulation failed; no transaction was sent')
    return null
  }
  throw Error('Signing is not installed')
}

// Workshop deployment boundary: public address only; no session lookup or signing code.
interface SendOutcome { txHash: string | null; status: 'confirmed' | 'failed' | 'unconfirmed' }
async function signAndSendTx(_bytes: string): Promise<SendOutcome> {
  throw Error('Signing is not installed in this read/build-only deployment')
}
async function whoami(): Promise<string> {
  const address = requireEnv('WAAP_AGENT_ADDRESS')
  if (!/^0x[0-9a-fA-F]{64}$/.test(address)) throw Error('WAAP_AGENT_ADDRESS must be a full public Sui address')
  return address
}

// agent.ts (part 6 of 6) — the tick loop
import fs from 'node:fs'
import path from 'node:path'
 
const AGENT_ID = 'sui-portfolio-rebalancer'
const LOG_FILE = path.resolve(process.env.AGENT_LOG_FILE ?? `./logs/${AGENT_ID}.jsonl`)
// The default path is ./logs/, which npm init does not create. Create it before the first
// write — appendFileSync throws ENOENT on a missing directory, and the logger swallows it,
// so the symptom is silence rather than an error.
fs.mkdirSync(path.dirname(LOG_FILE), { recursive: true })
const POLL_MS = Number(process.env.POLL_INTERVAL_MS ?? '60000')
const TARGET_ALLOCATION_USD = Number(requireEnv('TARGET_ALLOCATION_USD'))
const HIGH_PRICE_THRESHOLD = Number(requireEnv('HIGH_PRICE_THRESHOLD'))
const LOW_PRICE_THRESHOLD = Number(requireEnv('LOW_PRICE_THRESHOLD'))
 
function log(level: string, message: string, data: Record<string, unknown> = {}) {
  const entry = { ts: new Date().toISOString(), agent: AGENT_ID, level, message, ...data }
  const line = JSON.stringify(entry, (_key, value) => typeof value === 'bigint' ? value.toString() : value)
  console.log(line)
  fs.appendFileSync(LOG_FILE, line + '\n')   // see mkdir below — without it
  // the directory does not exist, this throws, the catch swallows it, and no log file appears
}
 
function logOutcome(direction: 'buy' | 'sell', amountUsd: number, r: SendOutcome | null) {
  if (!r) return   // dry run, already logged
  if (r.status === 'confirmed') log('event', 'rebalance_complete', { direction, amountUsd, txHash: r.txHash })
  else if (r.status === 'failed') log('error', 'rebalance_failed', { direction, amountUsd, txHash: r.txHash, error: 'reverted on-chain' })
  // Balances are re-read each tick, so a swap that lands later is not repeated.
  else log('warn', 'rebalance_unconfirmed', { direction, amountUsd, txHash: r.txHash })
}
 
async function tick(owner: string) {
  const { response } = await sui.ledgerService.getCheckpoint({ checkpointId: { oneofKind: undefined }, readMask: { paths: ['sequence_number', 'summary.timestamp'] } }, { abort: AbortSignal.timeout(15000) })
  const cp = response.checkpoint
  const stamp = cp?.summary?.timestamp
  const chainMs = stamp ? Number(stamp.seconds) * 1000 + Math.floor(stamp.nanos / 1e6) : NaN
  const age = Date.now() - chainMs
  if (!Number.isFinite(age) || age > 120000 || age < -30000) throw Error('Chain checkpoint stale or local clock incorrect')
  log('info', 'chain_checkpoint', { checkpoint: cp?.sequenceNumber?.toString(), chainTime: new Date(chainMs).toISOString(), source: SUI_RPC, note: 'Checkpoint before reads; subsequent reads are not an atomic snapshot' })
  const price = await getPoolPrice()
  const targetBalance = await getTokenBalance(owner, TARGET_TOKEN_TYPE)
  const quoteBalance = await getTokenBalance(owner, QUOTE_TOKEN_TYPE)
  const targetValueUsd = targetBalance * price
 
  log('info', 'price_check', {
    price: price.toFixed(6),
    highThreshold: HIGH_PRICE_THRESHOLD,
    lowThreshold: LOW_PRICE_THRESHOLD,
    targetBalance: targetBalance.toFixed(6),
    quoteBalance: quoteBalance.toFixed(2),
    targetValueUsd: targetValueUsd.toFixed(2),
    gasReserveSui: GAS_RESERVE_SUI,
  })
 
  if (targetBalance < GAS_RESERVE_SUI) {
    log('warn', 'funding_required', { reason: 'insufficient_gas_reserve', suiBalance: targetBalance, usdcBalance: quoteBalance, requiredSuiReserve: GAS_RESERVE_SUI, submitted: false })
    return 'BLOCKED_GAS_RESERVE'
  }
  if (price >= HIGH_PRICE_THRESHOLD) {
    const excessUsd = Math.min(targetValueUsd - TARGET_ALLOCATION_USD, (targetBalance - GAS_RESERVE_SUI) * price, MAX_TRADE_USD)
    if (excessUsd <= 0) { log('info', 'hold', { reason: 'target_or_gas_reserve_met' }); return 'HOLD' }
    log('event', 'rebalance_triggered', { direction: 'sell', price, excessUsd })
    try {
      logOutcome('sell', excessUsd, await executeSwap(owner, 'sell', excessUsd, price))
      return 'SIMULATED_UNSIGNED'
    } catch (err) {
      log('error', 'rebalance_failed', { direction: 'sell', error: String(err) })
      throw err
    }
  } else if (price <= LOW_PRICE_THRESHOLD) {
    const deficitUsd = TARGET_ALLOCATION_USD - targetValueUsd
    if (deficitUsd <= 0) { log('info', 'hold', { reason: 'target_met' }); return 'HOLD' }
    const buyAmountUsd = Math.min(deficitUsd, quoteBalance, MAX_TRADE_USD)
    if (buyAmountUsd < 0.01) {
      log('warn', 'insufficient_quote_balance', { deficitUsd, quoteBalance })
      return 'BLOCKED_CAPITAL'
    }
    log('event', 'rebalance_triggered', { direction: 'buy', price, buyAmountUsd })
    try {
      logOutcome('buy', buyAmountUsd, await executeSwap(owner, 'buy', buyAmountUsd, price))
      return 'SIMULATED_UNSIGNED'
    } catch (err) {
      log('error', 'rebalance_failed', { direction: 'buy', error: String(err) })
      throw err
    }
  } else {
    log('info', 'price_in_range', { price, low: LOW_PRICE_THRESHOLD, high: HIGH_PRICE_THRESHOLD })
    return 'HOLD'
  }
}
 
async function main() {
  if (![POLL_MS, TARGET_ALLOCATION_USD, HIGH_PRICE_THRESHOLD, LOW_PRICE_THRESHOLD].every(Number.isFinite) || POLL_MS < 30000 || TARGET_ALLOCATION_USD < 0 || LOW_PRICE_THRESHOLD < 0 || HIGH_PRICE_THRESHOLD <= LOW_PRICE_THRESHOLD) throw Error('Invalid poll interval, target or price thresholds')
  if (!Number.isFinite(GAS_RESERVE_SUI) || GAS_RESERVE_SUI < 0.01 || !Number.isFinite(MAX_TRADE_USD) || MAX_TRADE_USD <= 0) throw Error('Invalid gas reserve or trade cap')
  const owner = await whoami()
  initAggregator(owner)
 
  log('event', 'agent_start', {
    wallet: owner,
    network: NETWORK,
    targetToken: TARGET_TOKEN_TYPE,
    quoteToken: QUOTE_TOKEN_TYPE,
    targetAllocationUsd: TARGET_ALLOCATION_USD,
    highThreshold: HIGH_PRICE_THRESHOLD,
    lowThreshold: LOW_PRICE_THRESHOLD,
    poolId: CETUS_POOL_ID,
    slippageBps: SLIPPAGE_BPS,
    dryRun: DRY_RUN,
  })
 
  let stopping = false
  let wake = () => {}   // cuts the poll wait short on a stop signal
  for (const sig of ['SIGTERM', 'SIGINT'] as const) {
    process.on(sig, () => { log('info', 'shutdown_signal', { signal: sig }); stopping = true; wake() })
  }
 
  while (!stopping) {
    const startedAt = new Date().toISOString()
    try {
      const outcome = await tick(owner)
      const blocked = outcome?.startsWith('BLOCKED')
      log(blocked ? 'warn' : 'info', 'run_complete', { startedAt, outcome, successfulObservation: true, readyForUnsignedBuild: !blocked, readyToTrade: false, submitted: false })
      if (blocked && process.env.RUN_ONCE !== '0') process.exitCode = 2
    } catch (err) {
      log('error', 'run_complete', { startedAt, outcome: 'FAILED', error: String(err), successfulObservation: false, submitted: false })
      if (process.env.RUN_ONCE !== '0') process.exitCode = 1
    }
    if (stopping || process.env.RUN_ONCE !== '0') break
    await new Promise<void>((r) => {
      const t = setTimeout(r, POLL_MS)
      wake = () => { clearTimeout(t); r() }
    })
  }
}
 
main().catch((err) => {
  log('error', 'fatal', { error: String(err) })
  process.exit(1)
})
