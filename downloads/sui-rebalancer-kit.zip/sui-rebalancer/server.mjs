import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url)), recipe=path.join(root,'recipe'),stateDir=path.join(root,'state');
fs.mkdirSync(stateDir,{recursive:true,mode:0o700});
const port=Number(process.env.PORT||8788),origin=`http://127.0.0.1:${port}`,token=crypto.randomBytes(32).toString('hex');
const configFile=path.join(stateDir,'config.json'),eventFile=path.join(stateDir,'events.jsonl');
const source=()=>JSON.parse(fs.readFileSync(path.join(recipe,'SOURCE.json'),'utf8'));
const defaults={wallet:'',targetUsd:1,lowPrice:0.8,highPrice:1.6,pollSeconds:60,network:'mainnet',dryRun:true};
let config=fs.existsSync(configFile)?JSON.parse(fs.readFileSync(configFile,'utf8')):defaults;
let stage='idle',prepared=false,configured=fs.existsSync(configFile),installed=false,running=false,busy=false,child=null,timer=null,lastRun=null,error=null;
const events=[];
function emit(operation,status,message,data){const e={time:new Date().toISOString(),operation,status,message,...(data?{data}:{})};events.push(e);if(events.length>200)events.shift();fs.appendFileSync(eventFile,JSON.stringify(e)+'\n',{mode:0o600});return e;}
function status(){return {stage,runtime:{node:process.version,source:source(),installed,prepared,host:process.env.WORKSHOP_RUNTIME_LABEL||'Local computer'},config,configured,running,busy,lastRun,events,error};}
function childEnv(){return {PATH:process.env.PATH,HOME:process.env.HOME,TMPDIR:process.env.TMPDIR||'/tmp',LANG:'en_US.UTF-8',NETWORK:'mainnet',DRY_RUN:'1',RUN_ONCE:'1',WAAP_AGENT_ADDRESS:config.wallet,TARGET_ALLOCATION_USD:String(config.targetUsd),LOW_PRICE_THRESHOLD:String(config.lowPrice),HIGH_PRICE_THRESHOLD:String(config.highPrice),POLL_INTERVAL_MS:String(config.pollSeconds*1000),SLIPPAGE_BPS:'50',CETUS_POOL_ID:'0xb8d7d9e66a60c239e7a60110efcf8de6c705580ed924d0dde141f4a0e2c90105',TARGET_TOKEN_TYPE:'0x2::sui::SUI',QUOTE_TOKEN_TYPE:'0xdba34672e30cb065b1f93e3ab55318768fd6fef66c15942c9f7cb846e2f900e7::usdc::USDC',AGENT_LOG_FILE:path.join(stateDir,'agent.jsonl'),RECIPE_ENV_FILE:path.join(stateDir,'no-wallet-secrets.env')};}
function execute(command,args,{timeoutMs=90000,json=false}={}){return new Promise((resolve,reject)=>{const rows=[];let tail='',stderr='',expired=false;child=spawn(command,args,{cwd:recipe,env:childEnv(),stdio:['ignore','pipe','pipe']});const proc=child;const started=Date.now();const timeout=setTimeout(()=>{expired=true;proc.kill('SIGTERM');setTimeout(()=>proc.kill('SIGKILL'),3000).unref();},timeoutMs);proc.stdout.on('data',chunk=>{tail+=chunk;let at;while((at=tail.indexOf('\n'))>=0){const line=tail.slice(0,at);tail=tail.slice(at+1);if(json){try{const row=JSON.parse(line);rows.push(row);emit(row.message||'agent',row.level||'info',row.message||'Agent output',row);}catch{if(line.trim())emit('runtime','info',line.slice(0,500));}}else if(line.trim())emit('install','info',line.slice(0,500));}});proc.stderr.on('data',chunk=>{stderr=(stderr+chunk.toString()).slice(-4000);});proc.on('error',e=>{clearTimeout(timeout);if(child===proc)child=null;reject(e)});proc.on('close',(code,signal)=>{clearTimeout(timeout);if(child===proc)child=null;const result={startedAt:new Date(started).toISOString(),completedAt:new Date().toISOString(),durationMs:Date.now()-started,exitCode:code,signal,events:rows};if(json)lastRun=result;if(expired)reject(Error('Agent cycle timed out; stopped without submitting a transaction'));else if(code!==0){const funding=rows.find(r=>r.message==='funding_required');reject(Error(funding?'Wallet funding required: '+funding.reason+'; observed '+funding.suiBalance+' SUI and '+funding.usdcBalance+' USDC. No transaction submitted.':`Process stopped (${signal||code}). ${stderr.slice(-800)}`));}else resolve(result);});});}
function validate(c){if(!c||!/^0x[0-9a-fA-F]{64}$/.test(c.wallet||''))throw Error('A full public Sui wallet address is required');for(const k of ['targetUsd','lowPrice','highPrice','pollSeconds'])if(typeof c[k]!=='number'||!Number.isFinite(c[k]))throw Error(`Invalid ${k}`);if(c.targetUsd<=0||c.targetUsd>100000||c.lowPrice<=0||c.highPrice<=c.lowPrice||c.pollSeconds<30||c.pollSeconds>3600)throw Error('Check target, price thresholds and interval (30–3600 seconds)');return {wallet:c.wallet.toLowerCase(),targetUsd:c.targetUsd,lowPrice:c.lowPrice,highPrice:c.highPrice,pollSeconds:c.pollSeconds,network:'mainnet',dryRun:true};}
async function cycle(){if(busy)throw Error('An operation is already running');busy=true;error=null;emit('run','started','Starting the installed Rebalancer with actual wallet balances');try{await execute(process.execPath,['node_modules/tsx/dist/cli.mjs','agent.ts'],{json:true});emit('run','complete','Agent process exited; inspect the strategy outcome in its output');stage=running?'running':'deployed';}catch(e){error=e.message;emit('run','error',e.message);running=false;stage='error';throw e;}finally{busy=false;}}
function schedule(){if(!running)return;timer=setTimeout(async()=>{try{await cycle();}catch{}if(running)schedule();},config.pollSeconds*1000);}
async function action(body){const a=body.action;if(a==='stop'){running=false;clearTimeout(timer);timer=null;if(child){emit('stop','started','Stopping the active process');const p=child;p.kill('SIGTERM');await new Promise(resolve=>{const t=setTimeout(()=>{p.kill('SIGKILL');},5000);p.once('close',()=>{clearTimeout(t);resolve()});});}stage='stopped';emit('stop','complete','Stopped; no scheduled run remains');return;}
if(busy||running)throw Error('Stop the agent before changing its deployment or starting another operation');
if(a==='prepare'){if(Number(process.versions.node.split('.')[0])!==24)throw Error('Node 24 is required');for(const name of ['package-lock.json','agent.ts','SOURCE.json'])if(!fs.existsSync(path.join(recipe,name)))throw Error(`Missing recipe file: ${name}`);prepared=true;stage='prepared';emit('prepare','complete',`Node ${process.versions.node}; pinned source and lockfile found`);return;}
if(a==='configure'){if(!prepared)throw Error('Prepare the runtime first');config=validate(body.config);fs.writeFileSync(configFile,JSON.stringify(config,null,2),{mode:0o600});configured=true;stage=installed?'deployed':'configured';lastRun=null;emit('configure','complete','Public wallet and strategy saved; signing remains disabled',config);return;}
if(a==='deploy'){if(!prepared||!configured)throw Error('Prepare and configure first');busy=true;error=null;emit('deploy','started','Installing exact lockfile: npm ci --ignore-scripts');try{await execute('npm',['ci','--ignore-scripts','--no-audit','--no-fund'],{timeoutMs:180000});installed=true;stage='deployed';emit('deploy','complete','Standalone recipe installed; ready to run');}finally{busy=false;}return;}
if(a==='run'||a==='start'){if(!installed||!configured)throw Error('Deploy the configured recipe first');running=a==='start';if(running)stage='running';await cycle();if(running)schedule();return;}
throw Error('Unknown operation');}
function send(res,code,data){res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));}
const server=http.createServer(async(req,res)=>{try{if(req.headers.host!==`127.0.0.1:${port}`&&req.headers.host!==`localhost:${port}`){send(res,403,{error:'Local operator access only'});return;}const url=new URL(req.url,origin);if(req.method==='GET'&&url.pathname==='/api/session'){if(req.headers['sec-fetch-site']==='cross-site'){send(res,403,{error:'Open the local console directly'});return;}send(res,200,{token});return;}if(req.method==='GET'&&url.pathname==='/api/status'){send(res,200,status());return;}if(req.method==='POST'&&url.pathname==='/api/action'){if(req.headers.origin!==origin&&req.headers.origin!==`http://localhost:${port}`){send(res,403,{error:'Origin mismatch'});return;}if(req.headers['x-workshop-token']!==token){send(res,403,{error:'Open the local console first'});return;}let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>16384){send(res,413,{error:'Request too large'});return;}}try{await action(JSON.parse(raw));send(res,200,status());}catch(e){error=e.message;emit('operation','error',e.message);send(res,409,{...status(),error});}return;}const files={'/':['console/index.html','text/html'],'/index.html':['console/index.html','text/html'],'/app.js':['console/app.js','text/javascript'],'/style.css':['console/style.css','text/css'],'/source/agent.ts':['recipe/agent.ts','text/plain'],'/source/SOURCE.json':['recipe/SOURCE.json','application/json']};if(req.method==='GET'&&files[url.pathname]){const [f,type]=files[url.pathname];res.writeHead(200,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(fs.readFileSync(path.join(root,f)));return;}send(res,404,{error:'Not found'});}catch{send(res,500,{error:'Request failed'});}});
function openConsole(){
  if(!process.argv.includes('--open'))return;
  const command=process.platform==='darwin'?'open':process.platform==='win32'?'cmd':'xdg-open';
  const args=process.platform==='win32'?['/c','start','',origin]:[origin];
  const opener=spawn(command,args,{stdio:'ignore'});
  opener.on('error',()=>console.log(`Open ${origin} in your browser.`));opener.unref();
}
server.on('error',async err=>{
  if(err.code==='EADDRINUSE'){
    try{
      const response=await fetch(`${origin}/api/status`,{signal:AbortSignal.timeout(2500),redirect:'error'});
      const existing=await response.json();
      if(response.ok&&existing.runtime?.source?.source==='https://docs.waap.human.tech/recipes/sui-portfolio-rebalancer'&&existing.config?.network==='mainnet'&&existing.config?.dryRun===true){
        console.log(`A Rebalancer console is already available at ${origin}.`);
        console.log('Using that console; no second process was started. It may be forwarded from Studio.');
        openConsole();return;
      }
    }catch{}
    console.error(`Port ${port} is in use by another service. No process was stopped.`);
    console.error('Close that service only if you own it, or ask the workshop team for help.');
  }else console.error(`Could not start the console: ${err.message}`);
  process.exitCode=1;
});
server.listen(port,'127.0.0.1',()=>{
  console.log(`Rebalancer console: ${origin}`);
  console.log('Keep this terminal open. Press Control+C to close the console.');
  if(Number(process.versions.node.split('.')[0])!==24)console.log(`Node ${process.versions.node} detected. Install Node 24 before using Prepare.`);
  emit('server','ready',`Operator console ${origin}; transaction signing unavailable`);openConsole();
});
process.on('SIGTERM',()=>{running=false;clearTimeout(timer);child?.kill('SIGTERM');server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),6000).unref();});
