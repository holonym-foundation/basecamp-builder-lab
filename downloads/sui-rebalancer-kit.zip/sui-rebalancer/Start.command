#!/bin/bash
set -e
cd "$(dirname "$0")"
if [ -x /opt/homebrew/opt/node@24/bin/node ]; then export PATH="/opt/homebrew/opt/node@24/bin:$PATH"; fi
if ! command -v node >/dev/null 2>&1 || [ "$(node -p 'process.versions.node.split(".")[0]')" != 24 ]; then
  echo 'Install Node.js 24 from https://nodejs.org/en/download, then open Start.command again.'
  read -r -p 'Press Return to close.'
  exit 1
fi
exec node server.mjs --open
