#!/bin/bash
set -e
cd "$(dirname "$0")"
workshop_node=''
for candidate in "$(command -v node || true)" /opt/homebrew/opt/node@24/bin/node /usr/local/opt/node@24/bin/node; do
  if [ -x "$candidate" ] && [ "$("$candidate" -p 'process.versions.node.split(".")[0]' 2>/dev/null)" = 24 ]; then
    workshop_node="$candidate"
    break
  fi
done
if [ -z "$workshop_node" ]; then
  echo 'Install Node.js 24 from https://nodejs.org/en/download, then open Start.command again.'
  read -r -p 'Press Return to close.'
  exit 1
fi
export PATH="$(dirname "$workshop_node"):$PATH"
exec "$workshop_node" server.mjs --open
